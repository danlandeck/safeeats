import { getGrade } from "./grading";

// ── King County ──────────────────────────────────────────────────────────────
export function processKingCountyResults(data) {
  if (!Array.isArray(data) || data.length === 0) return [];
  const businesses = {};
  data.forEach((row) => {
    const id = row.business_id;
    if (!id) return;
    if (!businesses[id]) {
      businesses[id] = {
        business_id: id,
        name: row.name || row.inspection_business_name,
        address: row.address, city: row.city, zip_code: row.zip_code,
        phone: row.phone, description: row.description,
        inspections: [], allRows: [],
      };
    }
    businesses[id].allRows.push(row);
    const serial = row.inspection_serial_num;
    if (!businesses[id].inspections.find((i) => i.serial === serial)) {
      businesses[id].inspections.push({
        serial, date: row.inspection_date,
        score: parseInt(row.inspection_score) || 0,
        result: row.inspection_result,
      });
    }
  });
  return Object.values(businesses).map((biz) => {
    biz.inspections.sort((a, b) => new Date(b.date) - new Date(a.date));
    const latest = biz.inspections[0];
    const hasResult = latest?.result && latest.result.trim() !== "";
    const hasScore = latest?.score !== undefined && latest?.score !== null;
    const safetyScore = (hasResult || hasScore) && latest
      ? Math.max(0, Math.min(100, 100 - (latest.score || 0)))
      : null;
    const latestResult = hasResult ? latest.result : "Unknown";
    const rowWithCoords = biz.allRows.find((r) => r.latitude && r.longitude);
    return {
      ...biz, safetyScore, grade: safetyScore !== null ? getGrade(safetyScore) : "U",
      totalInspections: biz.inspections.length,
      latestDate: latest?.date, latestResult,
      latitude: rowWithCoords?.latitude, longitude: rowWithCoords?.longitude,
      isLLMData: false, source: "king",
      ada_compliance: "unknown",
    };
  });
}

export function kingToDetailRows(data) {
  return data; // raw rows pass through as-is
}

// ── NYC ───────────────────────────────────────────────────────────────────────
export function processNYCResults(data) {
  if (!Array.isArray(data) || data.length === 0) return [];
  const businesses = {};
  data.forEach((row) => {
    const id = row.camis;
    if (!id) return;
    if (!businesses[id]) {
      businesses[id] = {
        business_id: id,
        name: row.dba || row.aka_name,
        address: `${row.building || ""} ${row.street || ""}`.trim(),
        city: row.boro ? row.boro.charAt(0) + row.boro.slice(1).toLowerCase() : "New York City",
        zip_code: row.zipcode, phone: row.phone,
        description: row.cuisine_description || "",
        inspections: [], allRows: [],
      };
    }
    businesses[id].allRows.push(row);
    const key = `${row.inspection_date}-${row.inspection_type}`;
    if (!businesses[id].inspections.find((i) => i.serial === key)) {
      businesses[id].inspections.push({
        serial: key, date: row.inspection_date,
        score: parseInt(row.score) || 0, result: row.action || "",
      });
    }
  });
  return Object.values(businesses).map((biz) => {
    biz.inspections.sort((a, b) => new Date(b.date) - new Date(a.date));
    const latest = biz.inspections[0];
    const hasResult = latest?.result && latest.result.trim() !== "";
    const hasScore = latest?.score !== undefined && latest?.score !== null;
    const safetyScore = (hasResult || hasScore) && latest
      ? Math.max(0, Math.min(100, 100 - (latest.score || 0)))
      : null;
    const latestResult = hasResult ? latest.result : "Unknown";
    const rowWithCoords = biz.allRows.find((r) => r.latitude && r.longitude);
    return {
      ...biz, safetyScore, grade: safetyScore !== null ? getGrade(safetyScore) : "U",
      totalInspections: biz.inspections.length,
      latestDate: latest?.date, latestResult,
      latitude: rowWithCoords?.latitude, longitude: rowWithCoords?.longitude,
      isLLMData: false, source: "nyc",
      ada_compliance: "unknown",
    };
  });
}

export function nycToDetailRows(data) {
  return data.map((row) => ({
    inspection_serial_num: `${row.inspection_date}-${row.inspection_type}-${row.violation_code || Math.random()}`,
    inspection_date: row.inspection_date,
    inspection_score: String(row.score || 0),
    inspection_result: row.action || "",
    inspection_type: row.inspection_type || "",
    violation_description: row.violation_description || "",
    violation_type: row.critical_flag === "Critical" ? "RED" : "BLUE",
    violation_points: String(row.score || 0),
  }));
}

// ── Chicago ───────────────────────────────────────────────────────────────────
export function processChicagoResults(data) {
  if (!Array.isArray(data) || data.length === 0) return [];
  const businesses = {};
  data.forEach((row) => {
    const id = row.license_;
    const name = row.dba_name || row.aka_name;
    if (!id || !name) return;
    if (!businesses[id]) {
      businesses[id] = { business_id: id, name, address: row.address || "", city: "Chicago", zip_code: row.zip || "", phone: "", description: row.facility_type || "", inspections: [], allRows: [] };
    }
    businesses[id].allRows.push(row);
    if (!businesses[id].inspections.find((i) => i.serial === row.inspection_id)) {
      const result = row.results || "";
      const pts = result === "Pass" ? 8 : result === "Pass w/ Conditions" ? 24 : 55;
      businesses[id].inspections.push({ serial: row.inspection_id, date: row.inspection_date, score: pts, result });
    }
  });
  return Object.values(businesses).map((biz) => {
    biz.inspections.sort((a, b) => new Date(b.date) - new Date(a.date));
    const latest = biz.inspections[0];
    const safetyScore = Math.max(0, Math.min(100, 100 - (latest?.score || 0)));
    return {
      ...biz, safetyScore, grade: getGrade(safetyScore),
      totalInspections: biz.inspections.length,
      latestDate: latest?.date, latestResult: latest?.result,
      latitude: null, longitude: null, isLLMData: false, source: "chicago",
      ada_compliance: "unknown",
    };
  });
}

export function chicagoToDetailRows(data) {
  const rows = [];
  data.forEach((row) => {
    const result = row.results || "";
    const pts = result === "Pass" ? 8 : result === "Pass w/ Conditions" ? 24 : 55;
    const violations = (row.violations || "").split("|").map((v) => v.trim()).filter(Boolean);
    if (violations.length === 0) {
      rows.push({ inspection_serial_num: row.inspection_id, inspection_date: row.inspection_date, inspection_score: String(pts), inspection_result: result, inspection_type: row.inspection_type || "", violation_description: "", violation_type: "", violation_points: "0" });
    } else {
      violations.forEach((v) => {
        rows.push({ inspection_serial_num: row.inspection_id, inspection_date: row.inspection_date, inspection_score: String(pts), inspection_result: result, inspection_type: row.inspection_type || "", violation_description: v, violation_type: "BLUE", violation_points: "0" });
      });
    }
  });
  return rows;
}

// ── Montgomery County MD ──────────────────────────────────────────────────────
const MONTGOMERY_VKEYS = ["violation1","violation2","violation3","violation4","violation5","violation6a","violation6b","violation7a","violation7b","violation8","violation9"];

export function processMontgomeryResults(data) {
  if (!Array.isArray(data) || data.length === 0) return [];
  const businesses = {};
  data.forEach((row) => {
    const id = row.establishment_id;
    const name = row.name;
    if (!id || !name) return;
    if (!businesses[id]) {
      businesses[id] = { business_id: id, name, address: row.address1 || "", city: "Rockville", zip_code: row.zip || "", phone: "", description: "", inspections: [], allRows: [] };
    }
    businesses[id].allRows.push(row);
    const key = `${row.inspectiondate}-${row.inspectiontype}`;
    if (!businesses[id].inspections.find((i) => i.serial === key)) {
      const out = MONTGOMERY_VKEYS.filter((k) => row[k] === "Out of Compliance").length;
      const pts = out === 0 ? 5 : out === 1 ? 18 : out === 2 ? 30 : 45;
      businesses[id].inspections.push({ serial: key, date: row.inspectiondate, score: pts, result: row.inspectionresults || "" });
    }
  });
  return Object.values(businesses).map((biz) => {
    biz.inspections.sort((a, b) => new Date(b.date) - new Date(a.date));
    const latest = biz.inspections[0];
    const safetyScore = Math.max(0, Math.min(100, 100 - (latest?.score || 0)));
    return {
      ...biz, safetyScore, grade: getGrade(safetyScore),
      totalInspections: biz.inspections.length,
      latestDate: latest?.date, latestResult: latest?.result,
      latitude: null, longitude: null, isLLMData: false, source: "montgomery",
      ada_compliance: "unknown",
    };
  });
}

export function montgomeryToDetailRows(data) {
  const rows = [];
  data.forEach((row) => {
    const outViolations = MONTGOMERY_VKEYS.filter((k) => row[k] === "Out of Compliance");
    const pts = outViolations.length === 0 ? 5 : outViolations.length === 1 ? 18 : outViolations.length === 2 ? 30 : 45;
    const key = `${row.inspectiondate}-${row.inspectiontype || "inspection"}`;
    if (outViolations.length === 0) {
      rows.push({ inspection_serial_num: key, inspection_date: row.inspectiondate, inspection_score: String(pts), inspection_result: row.inspectionresults || "", inspection_type: row.inspectiontype || "", violation_description: "", violation_type: "", violation_points: "0" });
    } else {
      outViolations.forEach((k) => {
        rows.push({ inspection_serial_num: key, inspection_date: row.inspectiondate, inspection_score: String(pts), inspection_result: row.inspectionresults || "", inspection_type: row.inspectiontype || "", violation_description: `${k.replace("violation", "Violation ").toUpperCase()}: Out of Compliance`, violation_type: "RED", violation_points: "0" });
      });
    }
  });
  return rows;
}

// ── LLM (AI-assisted) ────────────────────────────────────────────────────────
export function llmToDetailRows(restaurant) {
  const rows = [];
  // Only process inspections that have a real date
  (restaurant.allInspections || []).filter((insp) => insp.date).forEach((insp, inspIndex) => {
    const violations = insp.violations || [];
    const penaltyPts = String(insp.violation_points ?? Math.max(0, 100 - (insp.score || 0)));
    if (violations.length === 0) {
      rows.push({
        inspection_serial_num: `llm-${inspIndex}`,
        inspection_date: insp.date, inspection_score: penaltyPts,
        inspection_result: insp.result || "Unknown", inspection_type: insp.type || "Routine",
        violation_description: "", violation_type: "", violation_points: "0",
      });
    } else {
      violations.forEach((v) => {
        rows.push({
          inspection_serial_num: `llm-${inspIndex}`,
          inspection_date: insp.date, inspection_score: penaltyPts,
          inspection_result: insp.result || "Unknown", inspection_type: insp.type || "Routine",
          violation_description: typeof v === "string" ? v : v.description || "",
          violation_type: typeof v === "object" && v.severity === "critical" ? "RED" : "BLUE",
          violation_points: typeof v === "object" ? String(v.points || 0) : "0",
        });
      });
    }
  });
  return rows;
}

export function buildLLMRestaurant(r, index, countyId, countyCity, fallbackScore) {
  // Determine if we actually have a real score from the LLM
  const hasViolationPoints = r.total_violation_points !== undefined && r.total_violation_points !== null;
  const hasLatestScore = r.latest_score !== undefined && r.latest_score !== null && Number(r.latest_score) > 0;

  let safetyScore = null;
  if (hasViolationPoints) {
    safetyScore = Math.max(0, Math.min(100, 100 - Number(r.total_violation_points)));
  } else if (hasLatestScore) {
    safetyScore = Math.max(0, Math.min(100, Number(r.latest_score)));
    // Only use passing-result inference if we truly have zero score but a clear pass result
    const isPassing = r.latest_result && /pass|satisf|complian|approved|ok/i.test(r.latest_result);
    if (isPassing && safetyScore < 75) safetyScore = 85;
  }
  // If neither is present, safetyScore stays null → shows as "U" / Unknown

  const history = r.inspection_history?.length > 0
    ? r.inspection_history
    : (r.latest_date ? [{ date: r.latest_date, total_violation_points: r.total_violation_points, result: r.latest_result, violations: r.violations }] : []);

  const allInspections = history.map((h, hi) => {
    const pts = h.total_violation_points != null ? Number(h.total_violation_points) : (safetyScore !== null ? Math.max(0, 100 - safetyScore) : 0);
    return {
      date: h.date || "",
      score: Math.max(0, Math.min(100, 100 - pts)),
      result: h.result || "",
      type: "Routine",
      violation_points: pts,
      violations: (h.violations || (hi === 0 ? r.violations : []) || []).map((v) => ({ description: v, severity: "minor", points: 0 })),
    };
  });

  const totalInspections = r.total_inspections || allInspections.length;

  return {
    business_id: `${countyId}-${index}-${r.name}`,
    name: r.name, address: r.address || "", city: r.city || countyCity,
    zip_code: r.zip_code || "", phone: r.phone || "", website: "", description: "",
    safetyScore,
    grade: safetyScore !== null ? getGrade(safetyScore) : "U",
    totalInspections,
    latestDate: r.latest_date || "", latestResult: r.latest_result || "",
    latitude: null, longitude: null,
    isLLMData: true, source: "llm",
    allInspections, allRows: [],
    cuisine: r.cuisine || "",
    is_vegan_friendly: r.is_vegan_friendly || false,
    is_vegetarian_friendly: r.is_vegetarian_friendly || false,
    is_kosher: r.is_kosher || false,
    is_halal: r.is_halal || false,
    is_gluten_free_options: r.is_gluten_free_options || false,
    dietary_tags: r.dietary_tags || [],
    ada_compliance: r.ada_compliance || "unknown",
  };
}

// ── Los Angeles CA ───────────────────────────────────────────────────────────
export function processLAResults(data) {
  if (!Array.isArray(data) || data.length === 0) return [];
  const businesses = {};
  data.forEach((row) => {
    const id = row.facility_id;
    if (!id) return;
    if (!businesses[id]) {
      businesses[id] = {
        business_id: id, name: row.facility_name,
        address: row.facility_address || "", city: row.facility_city || "Los Angeles",
        zip_code: row.facility_zip || "", phone: "", description: row.pe_description || "",
        inspections: [], allRows: [],
      };
    }
    businesses[id].allRows.push(row);
    const serial = row.serial_number;
    if (serial && !businesses[id].inspections.find((i) => i.serial === serial)) {
      const score = parseInt(row.score) || 0; // LA score is 0-100 direct (higher=better)
      businesses[id].inspections.push({ serial, date: row.activity_date, score, result: row.grade || "", type: row.service_description || "" });
    }
  });
  return Object.values(businesses).map((biz) => {
    biz.inspections.sort((a, b) => new Date(b.date) - new Date(a.date));
    const latest = biz.inspections[0];
    const safetyScore = latest?.score || 0; // already 0-100
    return {
      ...biz, safetyScore, grade: getGrade(safetyScore),
      totalInspections: biz.inspections.length,
      latestDate: latest?.date, latestResult: latest?.result,
      latitude: null, longitude: null, isLLMData: false, source: "la",
      ada_compliance: "unknown",
    };
  });
}

export function laToDetailRows(data) {
  const inspMap = {};
  data.forEach((row) => {
    const serial = row.serial_number || `${row.activity_date}-${row.facility_id}`;
    if (!inspMap[serial]) {
      const score = parseInt(row.score) || 0;
      inspMap[serial] = {
        inspection_serial_num: serial,
        inspection_date: row.activity_date,
        inspection_score: String(100 - score), // convert to penalty points for display
        inspection_result: row.grade || "",
        inspection_type: row.service_description || "",
        violations: [],
      };
    }
  });
  return Object.values(inspMap).map((insp) => ({ ...insp, violation_description: "", violation_type: "", violation_points: "0" }));
}

// ── Austin TX ────────────────────────────────────────────────────────────────
export function processAustinResults(data) {
  if (!Array.isArray(data) || data.length === 0) return [];
  const businesses = {};
  data.forEach((row) => {
    const id = row.facility_id;
    if (!id) return;
    if (!businesses[id]) {
      businesses[id] = { business_id: id, name: row.restaurant_name, address: row.address || "", city: row.city || "Austin", zip_code: row.zip_code || row.zip || "", phone: "", description: row.process_description || "", inspections: [], allRows: [] };
    }
    businesses[id].allRows.push(row);
    const key = `${row.inspection_date}-${row.inspection_type}`;
    if (!businesses[id].inspections.find((i) => i.serial === key)) {
      const pts = parseInt(row.score) || 0;
      const result = pts === 0 ? "Pass" : pts <= 15 ? "Pass" : pts <= 30 ? "Pass w/ Conditions" : "Fail";
      businesses[id].inspections.push({ serial: key, date: row.inspection_date, score: pts, result });
    }
  });
  return Object.values(businesses).map((biz) => {
    biz.inspections.sort((a, b) => new Date(b.date) - new Date(a.date));
    const latest = biz.inspections[0];
    const safetyScore = Math.max(0, Math.min(100, 100 - (latest?.score || 0)));
    return { ...biz, safetyScore, grade: getGrade(safetyScore), totalInspections: biz.inspections.length, latestDate: latest?.date, latestResult: latest?.result, latitude: null, longitude: null, isLLMData: false, source: "austin", ada_compliance: "unknown" };
  });
}

export function austinToDetailRows(data) {
  return data.map((row) => {
    const pts = parseInt(row.score) || 0;
    const result = pts === 0 ? "Pass" : pts <= 15 ? "Pass" : pts <= 30 ? "Pass w/ Conditions" : "Fail";
    return {
      inspection_serial_num: `${row.inspection_date}-${row.inspection_type}-${row.facility_id}`,
      inspection_date: row.inspection_date,
      inspection_score: String(pts),
      inspection_result: result,
      inspection_type: row.inspection_type || "",
      violation_description: row.violation_description || "",
      violation_type: "BLUE",
      violation_points: String(pts),
    };
  });
}

// ── San Francisco CA ──────────────────────────────────────────────────────────
export function processSFResults(data) {
  if (!Array.isArray(data) || data.length === 0) return [];
  const businesses = {};
  data.forEach((row) => {
    const id = row.business_id;
    if (!id) return;
    if (!businesses[id]) {
      businesses[id] = { business_id: id, name: row.business_name, address: row.business_address || "", city: row.business_city || "San Francisco", zip_code: row.business_zip || "", phone: "", description: "", inspections: [], allRows: [] };
    }
    businesses[id].allRows.push(row);
    const key = `${row.inspection_date}-${row.inspection_type || "routine"}`;
    if (!businesses[id].inspections.find((i) => i.serial === key)) {
      const score = parseInt(row.inspection_score) || 100;
      const pts = 100 - score;
      businesses[id].inspections.push({ serial: key, date: row.inspection_date, score: pts, result: score >= 90 ? "Pass" : score >= 70 ? "Conditional Pass" : "Fail" });
    }
  });
  return Object.values(businesses).map((biz) => {
    biz.inspections.sort((a, b) => new Date(b.date) - new Date(a.date));
    const latest = biz.inspections[0];
    const safetyScore = Math.max(0, Math.min(100, 100 - (latest?.score || 0)));
    const rowWithCoords = biz.allRows.find((r) => r.business_latitude && r.business_longitude);
    return { ...biz, safetyScore, grade: getGrade(safetyScore), totalInspections: biz.inspections.length, latestDate: latest?.date, latestResult: latest?.result, latitude: rowWithCoords?.business_latitude, longitude: rowWithCoords?.business_longitude, isLLMData: false, source: "sf", ada_compliance: "unknown" };
  });
}

export function sfToDetailRows(data) {
  const inspMap = {};
  data.forEach((row) => {
    const key = `${row.inspection_date}-${row.inspection_type || "routine"}-${row.business_id}`;
    if (!inspMap[key]) {
      const score = parseInt(row.inspection_score) || 100;
      inspMap[key] = {
        inspection_serial_num: key,
        inspection_date: row.inspection_date,
        inspection_score: String(100 - score),
        inspection_result: score >= 90 ? "Pass" : score >= 70 ? "Conditional Pass" : "Fail",
        inspection_type: row.inspection_type || "",
        violations: [],
      };
    }
    if (row.violation_description) {
      inspMap[key].violations.push({
        violation_description: row.violation_description,
        violation_type: row.risk_category === "High Risk" ? "RED" : "BLUE",
        violation_points: row.risk_category === "High Risk" ? "5" : "2",
      });
    }
  });
  const rows = [];
  Object.values(inspMap).forEach((insp) => {
    if (insp.violations.length === 0) {
      rows.push({ ...insp, violation_description: "", violation_type: "", violation_points: "0" });
    } else {
      insp.violations.forEach((v) => rows.push({ ...insp, ...v }));
    }
  });
  return rows;
}

// ── UK Food Standards Agency (FHRS) ──────────────────────────────────────────
// RatingValue: 0-5 (5=best). Scotland uses Pass/Improvement Required/Awaiting inspection.
// scores object: Hygiene (0=best,25=worst), Structural (0-25), ConfidenceInManagement (0-30)
// Total penalty = Hygiene + Structural + ConfidenceInManagement (max ~80)
// We convert to 0-100 safety score: 100 - (totalPenalty / 80 * 100), clamped.

function fhrsRatingToScore(est) {
  const rv = est.RatingValue;
  // Scotland/Wales use Pass/Improvement Required etc — map directly
  if (typeof rv === "string" && isNaN(parseInt(rv))) {
    if (/^pass/i.test(rv)) return 92;
    if (/improvement required/i.test(rv)) return 55;
    if (/awaiting/i.test(rv)) return null;
    return null;
  }
  const rating = parseInt(rv);
  if (isNaN(rating)) return null;
  // Use component scores if available (more precise)
  const h = est.scores?.Hygiene ?? null;
  const s = est.scores?.Structural ?? null;
  const c = est.scores?.ConfidenceInManagement ?? null;
  if (h !== null && s !== null && c !== null) {
    const penalty = h + s + c; // max ~80
    return Math.max(0, Math.min(100, Math.round(100 - (penalty / 80) * 100)));
  }
  // Fallback: map 0-5 star rating
  const starToScore = { 5: 95, 4: 82, 3: 68, 2: 52, 1: 35, 0: 15 };
  return starToScore[rating] ?? null;
}

export function processUKFSAResults(establishments) {
  if (!Array.isArray(establishments) || establishments.length === 0) return [];
  return establishments.map((est, i) => {
    const safetyScore = fhrsRatingToScore(est);
    const addr = [est.AddressLine1, est.AddressLine2].filter(Boolean).join(", ");
    const city = est.AddressLine3 || est.AddressLine4 || est.LocalAuthorityName || "UK";
    const ratingValue = est.RatingValue;
    const ratingLabel = isNaN(parseInt(ratingValue))
      ? ratingValue
      : `${ratingValue}/5 stars`;
    return {
      business_id: `uk-${est.FHRSID}`,
      name: est.BusinessName,
      address: addr,
      city,
      zip_code: est.PostCode || "",
      phone: est.Phone || "",
      website: "",
      description: est.BusinessType || "",
      safetyScore,
      grade: safetyScore !== null ? getGrade(safetyScore) : "U",
      totalInspections: est.RatingDate ? 1 : 0,
      latestDate: est.RatingDate ? est.RatingDate.split("T")[0] : "",
      latestResult: ratingLabel,
      latitude: est.geocode?.latitude || null,
      longitude: est.geocode?.longitude || null,
      isLLMData: false,
      source: "uk_fsa",
      county_id: "uk_fsa",
      fhrsId: est.FHRSID,
      localAuthority: est.LocalAuthorityName || "",
      newRatingPending: est.NewRatingPending,
      schemeType: est.SchemeType,
      ada_compliance: "unknown",
    };
  });
}

export function ukFSAToDetailRows(restaurant) {
  if (!restaurant.fhrsId) return [];
  // Build a synthetic inspection row from the data we have
  const h = restaurant._scores?.Hygiene;
  const s = restaurant._scores?.Structural;
  const c = restaurant._scores?.ConfidenceInManagement;
  const violations = [];
  if (h > 0) violations.push({ violation_description: `Hygiene: ${h > 15 ? "Major improvement necessary" : h > 5 ? "Some improvement necessary" : "Generally satisfactory"}`, violation_type: h > 15 ? "RED" : "BLUE", violation_points: String(h) });
  if (s > 0) violations.push({ violation_description: `Structural: ${s > 15 ? "Major improvement necessary" : s > 5 ? "Some improvement necessary" : "Generally satisfactory"}`, violation_type: s > 15 ? "RED" : "BLUE", violation_points: String(s) });
  if (c > 0) violations.push({ violation_description: `Confidence in Management: ${c > 20 ? "Major improvement necessary" : c > 10 ? "Some improvement necessary" : "Generally satisfactory"}`, violation_type: c > 20 ? "RED" : "BLUE", violation_points: String(c) });

  const row = {
    inspection_serial_num: `uk-${restaurant.fhrsId}`,
    inspection_date: restaurant.latestDate,
    inspection_score: String(Math.max(0, 100 - (restaurant.safetyScore || 0))),
    inspection_result: restaurant.latestResult || "",
    inspection_type: "Food Hygiene Rating (FSA)",
  };

  if (violations.length === 0) {
    return [{ ...row, violation_description: "", violation_type: "", violation_points: "0" }];
  }
  return violations.map((v) => ({ ...row, ...v }));
}

// ── Delaware ─────────────────────────────────────────────────────────────────
export function processDelawareResults(data) {
  if (!Array.isArray(data) || data.length === 0) return [];
  const businesses = {};
  data.forEach((row) => {
    const key = `${(row.restname || "").trim()}-${(row.restaddress || "").trim()}`;
    if (!key || key === "-") return;
    if (!businesses[key]) {
      businesses[key] = {
        business_id: key,
        name: (row.restname || "").trim(),
        address: (row.restaddress || "").trim(),
        city: (row.restcity || "").trim(),
        zip_code: (row.restzip || "").trim(),
        phone: "", description: "",
        inspections: [], allRows: [],
      };
    }
    businesses[key].allRows.push(row);
    const dateKey = `${row.insp_date}-${row.insp_type}`;
    if (!businesses[key].inspections.find((i) => i.serial === dateKey)) {
      businesses[key].inspections.push({
        serial: dateKey,
        date: row.insp_date ? row.insp_date.split("T")[0] : "",
        violation: row.violation || "",
        type: row.insp_type || "",
      });
    }
  });
  return Object.values(businesses).map((biz) => {
    biz.inspections.sort((a, b) => new Date(b.date) - new Date(a.date));
    // Group by inspection date to count violations per inspection
    const inspGroups = {};
    biz.allRows.forEach((r) => {
      const dk = `${r.insp_date}-${r.insp_type}`;
      if (!inspGroups[dk]) inspGroups[dk] = { date: r.insp_date ? r.insp_date.split("T")[0] : "", violations: 0 };
      if (r.violation && r.violation.trim()) inspGroups[dk].violations++;
    });
    const groups = Object.values(inspGroups).sort((a, b) => new Date(b.date) - new Date(a.date));
    const latest = groups[0];
    const violationCount = latest?.violations || 0;
    const safetyScore = violationCount === 0 ? 95 : violationCount <= 2 ? 80 : violationCount <= 5 ? 65 : violationCount <= 10 ? 50 : 30;
    return {
      ...biz, safetyScore, grade: getGrade(safetyScore),
      totalInspections: groups.length,
      latestDate: latest?.date,
      latestResult: violationCount === 0 ? "Pass" : "Violations Found",
      latitude: null, longitude: null, isLLMData: false, source: "delaware",
      ada_compliance: "unknown",
    };
  });
}

export function delawareToDetailRows(data) {
  const inspMap = {};
  data.forEach((row) => {
    const dateKey = `${row.insp_date}-${row.insp_type}`;
    const date = row.insp_date ? row.insp_date.split("T")[0] : "";
    if (!inspMap[dateKey]) {
      inspMap[dateKey] = { date, type: row.insp_type || "", violations: [] };
    }
    if (row.violation && row.violation.trim()) {
      inspMap[dateKey].violations.push(row.violation.trim());
    }
  });
  const rows = [];
  Object.entries(inspMap).forEach(([key, insp]) => {
    const violCount = insp.violations.length;
    const score = violCount === 0 ? 95 : violCount <= 2 ? 80 : violCount <= 5 ? 65 : 50;
    if (insp.violations.length === 0) {
      rows.push({ inspection_serial_num: key, inspection_date: insp.date, inspection_score: "0", inspection_result: "Pass", inspection_type: insp.type, violation_description: "", violation_type: "", violation_points: "0" });
    } else {
      insp.violations.forEach((v) => {
        rows.push({ inspection_serial_num: key, inspection_date: insp.date, inspection_score: String(100 - score), inspection_result: "Violations Found", inspection_type: insp.type, violation_description: v, violation_type: "BLUE", violation_points: "0" });
      });
    }
  });
  return rows;
}

// ── New York State ────────────────────────────────────────────────────────────
export function processNYStateResults(data) {
  if (!Array.isArray(data) || data.length === 0) return [];
  const businesses = {};
  data.forEach((row) => {
    const id = row.nys_health_operation_id;
    if (!id) return;
    if (!businesses[id]) {
      businesses[id] = {
        business_id: id,
        name: (row.facility || row.operation_name || "").trim(),
        address: (row.facility_address || row.address || "").trim(),
        city: (row.city || row.municipality || "").trim(),
        zip_code: (row.zip_code || "").trim(),
        phone: "", description: (row.description || "").trim(),
        inspections: [], allRows: [],
      };
    }
    businesses[id].allRows.push(row);
    const dateKey = row.date ? row.date.split("T")[0] : "";
    if (dateKey && !businesses[id].inspections.find((i) => i.serial === dateKey)) {
      const criticals = parseInt(row.total_critical_violations) || 0;
      const nonCriticals = parseInt(row.total_noncritical_violations) || 0;
      businesses[id].inspections.push({ serial: dateKey, date: dateKey, criticals, nonCriticals, type: row.inspection_type || "" });
    }
    // Update coords if available
    if (row.location1?.latitude && !businesses[id].latitude) {
      businesses[id].latitude = row.location1.latitude;
      businesses[id].longitude = row.location1.longitude;
    }
  });
  return Object.values(businesses).map((biz) => {
    biz.inspections.sort((a, b) => new Date(b.date) - new Date(a.date));
    const latest = biz.inspections[0];
    const c = latest?.criticals || 0;
    const nc = latest?.nonCriticals || 0;
    const pts = c * 7 + nc * 2; // weight criticals more
    const safetyScore = Math.max(0, Math.min(100, 100 - pts));
    return {
      ...biz, safetyScore, grade: getGrade(safetyScore),
      totalInspections: biz.inspections.length,
      latestDate: latest?.date,
      latestResult: c === 0 && nc === 0 ? "Pass" : c > 0 ? `${c} critical violation${c !== 1 ? "s" : ""}` : "Violations Found",
      isLLMData: false, source: "ny_state",
      ada_compliance: "unknown",
    };
  });
}

export function nyStateToDetailRows(data) {
  const inspMap = {};
  data.forEach((row) => {
    const dateKey = row.date ? row.date.split("T")[0] : "unknown";
    if (!inspMap[dateKey]) {
      const c = parseInt(row.total_critical_violations) || 0;
      const nc = parseInt(row.total_noncritical_violations) || 0;
      const pts = c * 7 + nc * 2;
      inspMap[dateKey] = {
        inspection_serial_num: dateKey,
        inspection_date: dateKey,
        inspection_score: String(pts),
        inspection_result: c === 0 && nc === 0 ? "Pass" : `${c} critical, ${nc} non-critical violations`,
        inspection_type: row.inspection_type || "",
        violations: (row.violations || "").split(";").map((v) => v.trim()).filter(Boolean),
      };
    }
  });
  const rows = [];
  Object.values(inspMap).forEach((insp) => {
    if (insp.violations.length === 0) {
      rows.push({ ...insp, violation_description: "", violation_type: "", violation_points: "0" });
    } else {
      insp.violations.forEach((v) => {
        rows.push({ ...insp, violation_description: v, violation_type: "BLUE", violation_points: "0" });
      });
    }
  });
  return rows;
}

// ── Toronto DineSafe (CKAN) ───────────────────────────────────────────────────
export function processTorontoResults(records) {
  if (!Array.isArray(records) || records.length === 0) return [];
  const businesses = {};
  records.forEach((row) => {
    const id = row["Establishment ID"];
    if (!id) return;
    if (!businesses[id]) {
      const addrRaw = row["Establishment Address"] || "";
      // Address format: "321 CARLAW AVE, Unit-103 None M4M 2S1" — extract postal code
      const postalMatch = addrRaw.match(/([A-Z]\d[A-Z]\s?\d[A-Z]\d)\s*$/);
      const postal = postalMatch ? postalMatch[1] : "";
      const address = addrRaw.replace(postalMatch?.[0] || "", "").replace(/None\s*$/, "").replace(/,\s*$/, "").trim();
      businesses[id] = {
        business_id: id,
        name: (row["Establishment Name"] || "").trim(),
        address, city: "Toronto", zip_code: postal,
        phone: "", description: row["Establishment Type"] || "",
        inspections: [], allRows: [],
        latitude: row.Latitude || null,
        longitude: row.Longitude || null,
      };
    }
    businesses[id].allRows.push(row);
    const dateKey = row["Inspection Date"] || "";
    if (dateKey && !businesses[id].inspections.find((i) => i.serial === dateKey)) {
      businesses[id].inspections.push({
        serial: dateKey, date: dateKey,
        severity: row.Severity || "", action: row.Action || "",
      });
    }
  });
  return Object.values(businesses).map((biz) => {
    biz.inspections.sort((a, b) => new Date(b.date) - new Date(a.date));
    // Count violations: C-Crucial, S-Significant, M-Minor
    const crucials = biz.allRows.filter((r) => (r.Severity || "").startsWith("C")).length;
    const significants = biz.allRows.filter((r) => (r.Severity || "").startsWith("S")).length;
    const minors = biz.allRows.filter((r) => (r.Severity || "").startsWith("M")).length;
    const pts = crucials * 10 + significants * 5 + minors * 2;
    const safetyScore = Math.max(0, Math.min(100, 100 - pts));
    const latest = biz.inspections[0];
    return {
      ...biz, safetyScore, grade: getGrade(safetyScore),
      totalInspections: new Set(biz.inspections.map((i) => i.date)).size,
      latestDate: latest?.date,
      latestResult: crucials > 0 ? "Crucial Infractions" : significants > 0 ? "Significant Infractions" : minors > 0 ? "Minor Infractions" : "Pass",
      isLLMData: false, source: "toronto",
      ada_compliance: "unknown",
    };
  });
}

export function torontoToDetailRows(records) {
  const inspMap = {};
  records.forEach((row) => {
    const dateKey = row["Inspection Date"] || "unknown";
    if (!inspMap[dateKey]) {
      inspMap[dateKey] = {
        inspection_serial_num: `toronto-${dateKey}`,
        inspection_date: dateKey,
        inspection_score: "0",
        inspection_result: row.Action || "",
        inspection_type: "DineSafe Inspection",
        violations: [],
      };
    }
    const infraction = (row["Infraction Details"] || "").trim();
    const severity = (row.Severity || "").trim();
    if (infraction && infraction.toLowerCase() !== "fail to ensure") {
      inspMap[dateKey].violations.push({ description: infraction, severity });
    }
  });
  const rows = [];
  Object.values(inspMap).forEach((insp) => {
    const crucials = insp.violations.filter((v) => v.severity.startsWith("C")).length;
    const significants = insp.violations.filter((v) => v.severity.startsWith("S")).length;
    const pts = crucials * 10 + significants * 5;
    insp.inspection_score = String(pts);
    if (insp.violations.length === 0) {
      rows.push({ ...insp, violation_description: "", violation_type: "", violation_points: "0" });
    } else {
      insp.violations.forEach((v) => {
        rows.push({ ...insp, violation_description: `${v.severity}: ${v.description}`, violation_type: v.severity.startsWith("C") ? "RED" : "BLUE", violation_points: v.severity.startsWith("C") ? "10" : v.severity.startsWith("S") ? "5" : "2" });
      });
    }
  });
  return rows;
}

// ── Reverse Geocoding ─────────────────────────────────────────────────────────
// Given lat/lng, returns { city, county, state, country } using Nominatim
export async function reverseGeocode(lat, lng) {
  try {
    const url = `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json&zoom=10`;
    const res = await fetch(url, { headers: { "User-Agent": "SafeEats/1.0" } });
    const data = await res.json();
    const addr = data.address || {};
    return {
      city: addr.city || addr.town || addr.village || addr.suburb || "",
      county: addr.county || "",
      state: addr.state || "",
      country: addr.country || "",
      countryCode: (addr.country_code || "").toUpperCase(),
      displayName: data.display_name || "",
    };
  } catch {
    return null;
  }
}

// ── Geocoding ─────────────────────────────────────────────────────────────────
// Works globally — stateOrCountry can be a US state abbr, country name, or city
export async function geocodeAddress(address, city, stateOrCountry) {
  // Build the most specific query we can, filtering out empty parts
  const parts = [address, city, stateOrCountry].filter(Boolean);
  const q = parts.join(", ");
  const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(q)}&format=json&limit=1`;
  const res = await fetch(url, { headers: { "User-Agent": "SafeEats/1.0" } });
  const data = await res.json();
  if (data.length > 0) return { latitude: data[0].lat, longitude: data[0].lon };
  // Fallback: try just city + country
  if (city && stateOrCountry) {
    const fallbackUrl = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(`${city}, ${stateOrCountry}`)}&format=json&limit=1`;
    const fallbackRes = await fetch(fallbackUrl, { headers: { "User-Agent": "SafeEats/1.0" } });
    const fallbackData = await fallbackRes.json();
    if (fallbackData.length > 0) return { latitude: fallbackData[0].lat, longitude: fallbackData[0].lon };
  }
  return null;
}
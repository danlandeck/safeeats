import React, { useState, useCallback, useMemo, useEffect, useRef, Suspense } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, GitCompareArrows, LocateFixed, Loader2 } from "lucide-react";
import { useLocation, Link } from "react-router-dom";
import { REGIONS } from "../utils/regions";
import { getTranslations } from "../utils/i18n";
import { useLanguage } from "../lib/LanguageContext";
import { llmToDetailRows, geocodeAddress, reverseGeocode } from "../utils/inspectionProcessors";
import { search as engineSearch, fetchDetail as engineFetchDetail } from "../utils/searchEngine";
import RestaurantCard from "../components/RestaurantCard";
import SmartSearchPanel from "../components/SmartSearchPanel";
import ConsentBanner, { useConsent } from "../components/ConsentBanner";
import HeroViolations from "../components/HeroViolations";
import AISearchStatus from "../components/AISearchStatus";
import RestaurantDetail from "../components/RestaurantDetail";

// Lazy-load heavy components so initial bundle is smaller
const CameraScanner = React.lazy(() => import("../components/CameraScanner"));
const MapView       = React.lazy(() => import("../components/MapView"));
const ScoreLegend   = React.lazy(() => import("../components/ScoreLegend"));
const ComparePanel  = React.lazy(() => import("../components/ComparePanel"));

export { getGrade } from "../utils/grading";
export { getGradeColor } from "../utils/grading";

// City aliases → { region, countyId } for all supported live API counties
const CITY_TO_COUNTY = {
  // King County, WA
  "seattle": { region: "washington", countyId: "king" },
  "bellevue": { region: "washington", countyId: "king" },
  "redmond": { region: "washington", countyId: "king" },
  "kirkland": { region: "washington", countyId: "king" },
  "renton": { region: "washington", countyId: "king" },
  "kent": { region: "washington", countyId: "king" },
  "burien": { region: "washington", countyId: "king" },
  "federal way": { region: "washington", countyId: "king" },
  "auburn": { region: "washington", countyId: "king" },
  "shoreline": { region: "washington", countyId: "king" },
  "bothell": { region: "washington", countyId: "king" },
  "sammamish": { region: "washington", countyId: "king" },
  "issaquah": { region: "washington", countyId: "king" },
  "king county": { region: "washington", countyId: "king" },
  "mercer island": { region: "washington", countyId: "king" },
  "newcastle": { region: "washington", countyId: "king" },
  "covington": { region: "washington", countyId: "king" },
  "maple valley": { region: "washington", countyId: "king" },
  "black diamond": { region: "washington", countyId: "king" },
  "enumclaw": { region: "washington", countyId: "king" },
  "duvall": { region: "washington", countyId: "king" },
  "snoqualmie": { region: "washington", countyId: "king" },
  "north bend": { region: "washington", countyId: "king" },
  "carnation": { region: "washington", countyId: "king" },
  "skykomish": { region: "washington", countyId: "king" },
  "tukwila": { region: "washington", countyId: "king" },
  "seatac": { region: "washington", countyId: "king" },
  "sea-tac": { region: "washington", countyId: "king" },
  "des moines": { region: "washington", countyId: "king" },
  "normandy park": { region: "washington", countyId: "king" },
  "algona": { region: "washington", countyId: "king" },
  "pacific": { region: "washington", countyId: "king" },
  "milton": { region: "washington", countyId: "king" },
  "medina": { region: "washington", countyId: "king" },
  "clyde hill": { region: "washington", countyId: "king" },
  "yarrow point": { region: "washington", countyId: "king" },
  "hunts point": { region: "washington", countyId: "king" },
  "beaux arts": { region: "washington", countyId: "king" },
  "lake forest park": { region: "washington", countyId: "king" },
  "kenmore": { region: "washington", countyId: "king" },
  "woodinville": { region: "washington", countyId: "king" },
  "capitol hill": { region: "washington", countyId: "king" },
  "ballard": { region: "washington", countyId: "king" },
  "fremont": { region: "washington", countyId: "king" },
  "queen anne": { region: "washington", countyId: "king" },
  "south lake union": { region: "washington", countyId: "king" },
  "pioneer square": { region: "washington", countyId: "king" },
  "chinatown": { region: "washington", countyId: "king" },
  "international district": { region: "washington", countyId: "king" },
  "belltown": { region: "washington", countyId: "king" },
  "west seattle": { region: "washington", countyId: "king" },
  "columbia city": { region: "washington", countyId: "king" },
  "rainier valley": { region: "washington", countyId: "king" },
  "u district": { region: "washington", countyId: "king" },
  "university district": { region: "washington", countyId: "king" },
  "greenwood": { region: "washington", countyId: "king" },
  "phinney ridge": { region: "washington", countyId: "king" },
  "wallingford": { region: "washington", countyId: "king" },
  "eastlake": { region: "washington", countyId: "king" },
  "madison park": { region: "washington", countyId: "king" },
  "montlake": { region: "washington", countyId: "king" },
  "madrona": { region: "washington", countyId: "king" },
  "beacon hill": { region: "washington", countyId: "king" },
  "georgetown": { region: "washington", countyId: "king" },
  "sodo": { region: "washington", countyId: "king" },
  "interbay": { region: "washington", countyId: "king" },
  "magnolia": { region: "washington", countyId: "king" },
  "crown hill": { region: "washington", countyId: "king" },
  "bitter lake": { region: "washington", countyId: "king" },
  "northgate": { region: "washington", countyId: "king" },
  "lake city": { region: "washington", countyId: "king" },
  "wedgwood": { region: "washington", countyId: "king" },
  "ravenna": { region: "washington", countyId: "king" },
  "bryant": { region: "washington", countyId: "king" },
  "sand point": { region: "washington", countyId: "king" },
  "maple leaf": { region: "washington", countyId: "king" },
  "victory heights": { region: "washington", countyId: "king" },
  "pinehurst": { region: "washington", countyId: "king" },
  "cedar park": { region: "washington", countyId: "king" },
  "olympic hills": { region: "washington", countyId: "king" },
  "haller lake": { region: "washington", countyId: "king" },
  "licton springs": { region: "washington", countyId: "king" },
  "green lake": { region: "washington", countyId: "king" },
  "tangletown": { region: "washington", countyId: "king" },
  "phinney": { region: "washington", countyId: "king" },
  "hawthorne hills": { region: "washington", countyId: "king" },
  "laurelhurst": { region: "washington", countyId: "king" },
  "leschi": { region: "washington", countyId: "king" },
  "mt baker": { region: "washington", countyId: "king" },
  "mount baker": { region: "washington", countyId: "king" },
  "seward park": { region: "washington", countyId: "king" },
  "hillman city": { region: "washington", countyId: "king" },
  "brighton": { region: "washington", countyId: "king" },
  "dunlap": { region: "washington", countyId: "king" },
  "skyway": { region: "washington", countyId: "king" },
  "delridge": { region: "washington", countyId: "king" },
  "highland park": { region: "washington", countyId: "king" },
  "riverview": { region: "washington", countyId: "king" },
  "south park": { region: "washington", countyId: "king" },
  "fauntleroy": { region: "washington", countyId: "king" },
  "admiral": { region: "washington", countyId: "king" },
  "alki": { region: "washington", countyId: "king" },
  "junction": { region: "washington", countyId: "king" },
  "white center": { region: "washington", countyId: "king" },
  "arbor heights": { region: "washington", countyId: "king" },
  // NYC
  "new york": { region: "new_york", countyId: "nyc" },
  "new york city": { region: "new_york", countyId: "nyc" },
  "nyc": { region: "new_york", countyId: "nyc" },
  "manhattan": { region: "new_york", countyId: "nyc" },
  "brooklyn": { region: "new_york", countyId: "nyc" },
  "queens": { region: "new_york", countyId: "nyc" },
  "bronx": { region: "new_york", countyId: "nyc" },
  "the bronx": { region: "new_york", countyId: "nyc" },
  "staten island": { region: "new_york", countyId: "nyc" },
  "harlem": { region: "new_york", countyId: "nyc" },
  "upper east side": { region: "new_york", countyId: "nyc" },
  "upper west side": { region: "new_york", countyId: "nyc" },
  "midtown": { region: "new_york", countyId: "nyc" },
  "chelsea": { region: "new_york", countyId: "nyc" },
  "hell's kitchen": { region: "new_york", countyId: "nyc" },
  "hells kitchen": { region: "new_york", countyId: "nyc" },
  "lower east side": { region: "new_york", countyId: "nyc" },
  "east village": { region: "new_york", countyId: "nyc" },
  "west village": { region: "new_york", countyId: "nyc" },
  "greenwich village": { region: "new_york", countyId: "nyc" },
  "soho": { region: "new_york", countyId: "nyc" },
  "tribeca": { region: "new_york", countyId: "nyc" },
  "financial district": { region: "new_york", countyId: "nyc" },
  "little italy": { region: "new_york", countyId: "nyc" },
  "nolita": { region: "new_york", countyId: "nyc" },
  "noho": { region: "new_york", countyId: "nyc" },
  "gramercy": { region: "new_york", countyId: "nyc" },
  "flatiron": { region: "new_york", countyId: "nyc" },
  "murray hill": { region: "new_york", countyId: "nyc" },
  "kips bay": { region: "new_york", countyId: "nyc" },
  "inwood": { region: "new_york", countyId: "nyc" },
  "washington heights": { region: "new_york", countyId: "nyc" },
  "morningside heights": { region: "new_york", countyId: "nyc" },
  "hamilton heights": { region: "new_york", countyId: "nyc" },
  "williamsburg": { region: "new_york", countyId: "nyc" },
  "bushwick": { region: "new_york", countyId: "nyc" },
  "bed stuy": { region: "new_york", countyId: "nyc" },
  "bedford stuyvesant": { region: "new_york", countyId: "nyc" },
  "park slope": { region: "new_york", countyId: "nyc" },
  "crown heights": { region: "new_york", countyId: "nyc" },
  "flatbush": { region: "new_york", countyId: "nyc" },
  "borough park": { region: "new_york", countyId: "nyc" },
  "sunset park": { region: "new_york", countyId: "nyc" },
  "bay ridge": { region: "new_york", countyId: "nyc" },
  "bensonhurst": { region: "new_york", countyId: "nyc" },
  "coney island": { region: "new_york", countyId: "nyc" },
  "brighton beach": { region: "new_york", countyId: "nyc" },
  "dumbo": { region: "new_york", countyId: "nyc" },
  "boerum hill": { region: "new_york", countyId: "nyc" },
  "cobble hill": { region: "new_york", countyId: "nyc" },
  "carroll gardens": { region: "new_york", countyId: "nyc" },
  "red hook": { region: "new_york", countyId: "nyc" },
  "greenpoint": { region: "new_york", countyId: "nyc" },
  "astoria": { region: "new_york", countyId: "nyc" },
  "flushing": { region: "new_york", countyId: "nyc" },
  "jackson heights": { region: "new_york", countyId: "nyc" },
  "jamaica": { region: "new_york", countyId: "nyc" },
  "long island city": { region: "new_york", countyId: "nyc" },
  "forest hills": { region: "new_york", countyId: "nyc" },
  "ridgewood": { region: "new_york", countyId: "nyc" },
  "bayside": { region: "new_york", countyId: "nyc" },
  "howard beach": { region: "new_york", countyId: "nyc" },
  "rego park": { region: "new_york", countyId: "nyc" },
  // Chicago / Cook County
  "chicago": { region: "illinois", countyId: "cook" },
  "cook county": { region: "illinois", countyId: "cook" },
  "evanston": { region: "illinois", countyId: "cook" },
  "skokie": { region: "illinois", countyId: "cook" },
  "oak park": { region: "illinois", countyId: "cook" },
  "berwyn": { region: "illinois", countyId: "cook" },
  "cicero": { region: "illinois", countyId: "cook" },
  "des plaines": { region: "illinois", countyId: "cook" },
  "elk grove village": { region: "illinois", countyId: "cook" },
  "schaumburg": { region: "illinois", countyId: "cook" },
  "palatine": { region: "illinois", countyId: "cook" },
  "arlington heights": { region: "illinois", countyId: "cook" },
  "mount prospect": { region: "illinois", countyId: "cook" },
  "niles": { region: "illinois", countyId: "cook" },
  "park ridge": { region: "illinois", countyId: "cook" },
  "rosemont": { region: "illinois", countyId: "cook" },
  "northbrook": { region: "illinois", countyId: "cook" },
  "glenview": { region: "illinois", countyId: "cook" },
  "wilmette": { region: "illinois", countyId: "cook" },
  "harvey": { region: "illinois", countyId: "cook" },
  "oak lawn": { region: "illinois", countyId: "cook" },
  "evergreen park": { region: "illinois", countyId: "cook" },
  "blue island": { region: "illinois", countyId: "cook" },
  "orland park": { region: "illinois", countyId: "cook" },
  "tinley park": { region: "illinois", countyId: "cook" },
  "maywood il": { region: "illinois", countyId: "cook" },
  "melrose park": { region: "illinois", countyId: "cook" },
  "forest park": { region: "illinois", countyId: "cook" },
  "river forest": { region: "illinois", countyId: "cook" },
  "calumet city": { region: "illinois", countyId: "cook" },
  "wicker park": { region: "illinois", countyId: "cook" },
  "logan square": { region: "illinois", countyId: "cook" },
  "bucktown": { region: "illinois", countyId: "cook" },
  "pilsen": { region: "illinois", countyId: "cook" },
  "wrigleyville": { region: "illinois", countyId: "cook" },
  "lincoln park": { region: "illinois", countyId: "cook" },
  "lakeview": { region: "illinois", countyId: "cook" },
  "andersonville": { region: "illinois", countyId: "cook" },
  "rogers park": { region: "illinois", countyId: "cook" },
  "hyde park": { region: "illinois", countyId: "cook" },
  "bronzeville": { region: "illinois", countyId: "cook" },
  "bridgeport": { region: "illinois", countyId: "cook" },
  "river north": { region: "illinois", countyId: "cook" },
  "gold coast": { region: "illinois", countyId: "cook" },
  "streeterville": { region: "illinois", countyId: "cook" },
  "south loop": { region: "illinois", countyId: "cook" },
  "west loop": { region: "illinois", countyId: "cook" },
  "greektown": { region: "illinois", countyId: "cook" },
  "avondale": { region: "illinois", countyId: "cook" },
  "portage park": { region: "illinois", countyId: "cook" },
  "irving park": { region: "illinois", countyId: "cook" },
  "jefferson park": { region: "illinois", countyId: "cook" },
  "edgewater": { region: "illinois", countyId: "cook" },
  "uptown": { region: "illinois", countyId: "cook" },
  "ravenswood": { region: "illinois", countyId: "cook" },
  "lincoln square": { region: "illinois", countyId: "cook" },
  // Austin / Travis County
  "austin": { region: "texas", countyId: "travis" },
  "travis county": { region: "texas", countyId: "travis" },
  "pflugerville": { region: "texas", countyId: "travis" },
  "manor": { region: "texas", countyId: "travis" },
  "lago vista": { region: "texas", countyId: "travis" },
  "rollingwood": { region: "texas", countyId: "travis" },
  "west lake hills": { region: "texas", countyId: "travis" },
  "bee cave": { region: "texas", countyId: "travis" },
  "lakeway": { region: "texas", countyId: "travis" },
  "spicewood": { region: "texas", countyId: "travis" },
  "south congress": { region: "texas", countyId: "travis" },
  "east austin": { region: "texas", countyId: "travis" },
  "zilker": { region: "texas", countyId: "travis" },
  "bouldin creek": { region: "texas", countyId: "travis" },
  "travis heights": { region: "texas", countyId: "travis" },
  "clarksville": { region: "texas", countyId: "travis" },
  "mueller": { region: "texas", countyId: "travis" },
  "cherrywood": { region: "texas", countyId: "travis" },
  "crestview": { region: "texas", countyId: "travis" },
  "allandale": { region: "texas", countyId: "travis" },
  "rosedale": { region: "texas", countyId: "travis" },
  "tarrytown": { region: "texas", countyId: "travis" },
  "north loop austin": { region: "texas", countyId: "travis" },
  // San Francisco
  "san francisco": { region: "california", countyId: "sf" },
  "sf": { region: "california", countyId: "sf" },
  "mission district": { region: "california", countyId: "sf" },
  "the mission": { region: "california", countyId: "sf" },
  "castro": { region: "california", countyId: "sf" },
  "haight ashbury": { region: "california", countyId: "sf" },
  "haight-ashbury": { region: "california", countyId: "sf" },
  "tenderloin": { region: "california", countyId: "sf" },
  "soma": { region: "california", countyId: "sf" },
  "south of market": { region: "california", countyId: "sf" },
  "north beach": { region: "california", countyId: "sf" },
  "fishermans wharf": { region: "california", countyId: "sf" },
  "nob hill": { region: "california", countyId: "sf" },
  "russian hill": { region: "california", countyId: "sf" },
  "pacific heights": { region: "california", countyId: "sf" },
  "marina district": { region: "california", countyId: "sf" },
  "cow hollow": { region: "california", countyId: "sf" },
  "richmond district": { region: "california", countyId: "sf" },
  "inner richmond": { region: "california", countyId: "sf" },
  "outer richmond": { region: "california", countyId: "sf" },
  "sunset district": { region: "california", countyId: "sf" },
  "inner sunset": { region: "california", countyId: "sf" },
  "outer sunset": { region: "california", countyId: "sf" },
  "excelsior": { region: "california", countyId: "sf" },
  "bernal heights": { region: "california", countyId: "sf" },
  "potrero hill": { region: "california", countyId: "sf" },
  "dogpatch": { region: "california", countyId: "sf" },
  "bayview": { region: "california", countyId: "sf" },
  "hunters point": { region: "california", countyId: "sf" },
  "visitacion valley": { region: "california", countyId: "sf" },
  "glen park": { region: "california", countyId: "sf" },
  "noe valley": { region: "california", countyId: "sf" },
  "hayes valley": { region: "california", countyId: "sf" },
  "western addition": { region: "california", countyId: "sf" },
  "fillmore": { region: "california", countyId: "sf" },
  "japantown": { region: "california", countyId: "sf" },
  "lower haight": { region: "california", countyId: "sf" },
  "upper haight": { region: "california", countyId: "sf" },
  "alamo square": { region: "california", countyId: "sf" },
  "twin peaks": { region: "california", countyId: "sf" },
  "west portal": { region: "california", countyId: "sf" },
  "miraloma park": { region: "california", countyId: "sf" },
  "duboce triangle": { region: "california", countyId: "sf" },
  "forest hill sf": { region: "california", countyId: "sf" },
  // Los Angeles County
  "los angeles": { region: "california", countyId: "la" },
  "la": { region: "california", countyId: "la" },
  "hollywood": { region: "california", countyId: "la" },
  "santa monica": { region: "california", countyId: "la" },
  "long beach": { region: "california", countyId: "la" },
  "pasadena": { region: "california", countyId: "la" },
  "burbank": { region: "california", countyId: "la" },
  "glendale": { region: "california", countyId: "la" },
  "compton": { region: "california", countyId: "la" },
  "inglewood": { region: "california", countyId: "la" },
  "torrance": { region: "california", countyId: "la" },
  "hawthorne": { region: "california", countyId: "la" },
  "el monte": { region: "california", countyId: "la" },
  "pomona": { region: "california", countyId: "la" },
  "west covina": { region: "california", countyId: "la" },
  "downey": { region: "california", countyId: "la" },
  "norwalk": { region: "california", countyId: "la" },
  "whittier": { region: "california", countyId: "la" },
  "carson": { region: "california", countyId: "la" },
  "lakewood": { region: "california", countyId: "la" },
  "west hollywood": { region: "california", countyId: "la" },
  "beverly hills": { region: "california", countyId: "la" },
  "culver city": { region: "california", countyId: "la" },
  "el segundo": { region: "california", countyId: "la" },
  "manhattan beach": { region: "california", countyId: "la" },
  "hermosa beach": { region: "california", countyId: "la" },
  "redondo beach": { region: "california", countyId: "la" },
  "gardena": { region: "california", countyId: "la" },
  "lawndale": { region: "california", countyId: "la" },
  "lynwood": { region: "california", countyId: "la" },
  "south gate": { region: "california", countyId: "la" },
  "bell": { region: "california", countyId: "la" },
  "huntington park": { region: "california", countyId: "la" },
  "maywood": { region: "california", countyId: "la" },
  "bell gardens": { region: "california", countyId: "la" },
  "cudahy": { region: "california", countyId: "la" },
  "pico rivera": { region: "california", countyId: "la" },
  "montebello": { region: "california", countyId: "la" },
  "commerce": { region: "california", countyId: "la" },
  "vernon": { region: "california", countyId: "la" },
  "san gabriel": { region: "california", countyId: "la" },
  "alhambra": { region: "california", countyId: "la" },
  "temple city": { region: "california", countyId: "la" },
  "rosemead": { region: "california", countyId: "la" },
  "monterey park": { region: "california", countyId: "la" },
  "san marino": { region: "california", countyId: "la" },
  "arcadia": { region: "california", countyId: "la" },
  "monrovia": { region: "california", countyId: "la" },
  "duarte": { region: "california", countyId: "la" },
  "azusa": { region: "california", countyId: "la" },
  "covina": { region: "california", countyId: "la" },
  "glendora": { region: "california", countyId: "la" },
  "san dimas": { region: "california", countyId: "la" },
  "la verne": { region: "california", countyId: "la" },
  "claremont": { region: "california", countyId: "la" },
  "montclair": { region: "california", countyId: "la" },
  "diamond bar": { region: "california", countyId: "la" },
  "walnut": { region: "california", countyId: "la" },
  "rowland heights": { region: "california", countyId: "la" },
  "hacienda heights": { region: "california", countyId: "la" },
  "la puente": { region: "california", countyId: "la" },
  "industry": { region: "california", countyId: "la" },
  "baldwin park": { region: "california", countyId: "la" },
  "irwindale": { region: "california", countyId: "la" },
  "southgate": { region: "california", countyId: "la" },
  "cerritos": { region: "california", countyId: "la" },
  "artesia": { region: "california", countyId: "la" },
  "bellflower": { region: "california", countyId: "la" },
  "paramount": { region: "california", countyId: "la" },
  "signal hill": { region: "california", countyId: "la" },
  "los alamitos": { region: "california", countyId: "la" },
  "calabasas": { region: "california", countyId: "la" },
  "hidden hills": { region: "california", countyId: "la" },
  "agoura hills": { region: "california", countyId: "la" },
  "westlake village": { region: "california", countyId: "la" },
  "thousand oaks": { region: "california", countyId: "la" },
  "malibu": { region: "california", countyId: "la" },
  "san fernando": { region: "california", countyId: "la" },
  "sylmar": { region: "california", countyId: "la" },
  "pacoima": { region: "california", countyId: "la" },
  "sun valley": { region: "california", countyId: "la" },
  "north hollywood": { region: "california", countyId: "la" },
  "studio city": { region: "california", countyId: "la" },
  "sherman oaks": { region: "california", countyId: "la" },
  "van nuys": { region: "california", countyId: "la" },
  "reseda": { region: "california", countyId: "la" },
  "canoga park": { region: "california", countyId: "la" },
  "chatsworth": { region: "california", countyId: "la" },
  "northridge": { region: "california", countyId: "la" },
  "granada hills": { region: "california", countyId: "la" },
  "porter ranch": { region: "california", countyId: "la" },
  "encino": { region: "california", countyId: "la" },
  "tarzana": { region: "california", countyId: "la" },
  "woodland hills": { region: "california", countyId: "la" },
  "west hills": { region: "california", countyId: "la" },
  "winnetka": { region: "california", countyId: "la" },
  "east los angeles": { region: "california", countyId: "la" },
  "east la": { region: "california", countyId: "la" },
  "koreatown": { region: "california", countyId: "la" },
  "silver lake": { region: "california", countyId: "la" },
  "echo park": { region: "california", countyId: "la" },
  "los feliz": { region: "california", countyId: "la" },
  "atwater village": { region: "california", countyId: "la" },
  "glassell park": { region: "california", countyId: "la" },
  "highland park la": { region: "california", countyId: "la" },
  "eagle rock": { region: "california", countyId: "la" },
  "boyle heights": { region: "california", countyId: "la" },
  "downtown la": { region: "california", countyId: "la" },
  "dtla": { region: "california", countyId: "la" },
  "little tokyo": { region: "california", countyId: "la" },
  "chinatown la": { region: "california", countyId: "la" },
  "arts district": { region: "california", countyId: "la" },
  "venice": { region: "california", countyId: "la" },
  "mar vista": { region: "california", countyId: "la" },
  "westwood": { region: "california", countyId: "la" },
  "brentwood": { region: "california", countyId: "la" },
  "pacific palisades": { region: "california", countyId: "la" },
  "playa del rey": { region: "california", countyId: "la" },
  "westchester": { region: "california", countyId: "la" },
  "ladera heights": { region: "california", countyId: "la" },
  "view park": { region: "california", countyId: "la" },
  "leimert park": { region: "california", countyId: "la" },
  "crenshaw": { region: "california", countyId: "la" },
  "mid city": { region: "california", countyId: "la" },
  "palms": { region: "california", countyId: "la" },
  "sawtelle": { region: "california", countyId: "la" },
  "century city": { region: "california", countyId: "la" },
  // Canada
  "canada": { region: "canada", countyId: "toronto", locationLabel: "Canada" },
  "canadian": { region: "canada", countyId: "toronto", locationLabel: "Canada" },
  "ontario": { region: "canada", countyId: "toronto", locationLabel: "Ontario, Canada" },
  "toronto": { region: "canada", countyId: "toronto", locationLabel: "Toronto, Ontario, Canada" },
  "ottawa": { region: "canada", countyId: "ottawa", locationLabel: "Ottawa, Ontario, Canada" },
  "hamilton ontario": { region: "canada", countyId: "hamilton_on", locationLabel: "Hamilton, Ontario, Canada" },
  "mississauga": { region: "canada", countyId: "mississauga", locationLabel: "Mississauga, Ontario, Canada" },
  "brampton": { region: "canada", countyId: "brampton", locationLabel: "Brampton, Ontario, Canada" },
  "london ontario": { region: "canada", countyId: "london_on", locationLabel: "London, Ontario, Canada" },
  "kitchener": { region: "canada", countyId: "kitchener", locationLabel: "Kitchener, Ontario, Canada" },
  "waterloo ontario": { region: "canada", countyId: "kitchener", locationLabel: "Waterloo, Ontario, Canada" },
  "guelph": { region: "canada", countyId: "kitchener", locationLabel: "Guelph, Ontario, Canada" },
  "windsor ontario": { region: "canada", countyId: "toronto", locationLabel: "Windsor, Ontario, Canada" },
  "barrie": { region: "canada", countyId: "toronto", locationLabel: "Barrie, Ontario, Canada" },
  "british columbia": { region: "canada", countyId: "vancouver", locationLabel: "British Columbia, Canada" },
  "bc": { region: "canada", countyId: "vancouver", locationLabel: "British Columbia, Canada" },
  "vancouver": { region: "canada", countyId: "vancouver", locationLabel: "Vancouver, British Columbia, Canada" },
  "surrey bc": { region: "canada", countyId: "surrey", locationLabel: "Surrey, British Columbia, Canada" },
  "burnaby": { region: "canada", countyId: "burnaby", locationLabel: "Burnaby, British Columbia, Canada" },
  "richmond bc": { region: "canada", countyId: "richmond_bc", locationLabel: "Richmond, British Columbia, Canada" },
  "victoria bc": { region: "canada", countyId: "victoria_bc", locationLabel: "Victoria, British Columbia, Canada" },
  "victoria british columbia": { region: "canada", countyId: "victoria_bc", locationLabel: "Victoria, British Columbia, Canada" },
  "kelowna": { region: "canada", countyId: "kelowna", locationLabel: "Kelowna, British Columbia, Canada" },
  "abbotsford": { region: "canada", countyId: "vancouver", locationLabel: "Abbotsford, British Columbia, Canada" },
  "langley": { region: "canada", countyId: "vancouver", locationLabel: "Langley, British Columbia, Canada" },
  "north vancouver": { region: "canada", countyId: "vancouver", locationLabel: "North Vancouver, British Columbia, Canada" },
  "west vancouver": { region: "canada", countyId: "vancouver", locationLabel: "West Vancouver, British Columbia, Canada" },
  "coquitlam": { region: "canada", countyId: "burnaby", locationLabel: "Coquitlam, British Columbia, Canada" },
  "delta bc": { region: "canada", countyId: "surrey", locationLabel: "Delta, British Columbia, Canada" },
  "new westminster": { region: "canada", countyId: "burnaby", locationLabel: "New Westminster, British Columbia, Canada" },
  "nanaimo": { region: "canada", countyId: "victoria_bc", locationLabel: "Nanaimo, British Columbia, Canada" },
  "kamloops": { region: "canada", countyId: "kelowna", locationLabel: "Kamloops, British Columbia, Canada" },
  "prince george bc": { region: "canada", countyId: "kelowna", locationLabel: "Prince George, British Columbia, Canada" },
  "quebec": { region: "canada", countyId: "montreal", locationLabel: "Québec, Canada" },
  "québec": { region: "canada", countyId: "montreal", locationLabel: "Québec, Canada" },
  "montreal": { region: "canada", countyId: "montreal", locationLabel: "Montréal, Québec, Canada" },
  "montréal": { region: "canada", countyId: "montreal", locationLabel: "Montréal, Québec, Canada" },
  "quebec city": { region: "canada", countyId: "quebec_city", locationLabel: "Québec City, Québec, Canada" },
  "québec city": { region: "canada", countyId: "quebec_city", locationLabel: "Québec City, Québec, Canada" },
  "laval": { region: "canada", countyId: "laval", locationLabel: "Laval, Québec, Canada" },
  "gatineau": { region: "canada", countyId: "gatineau", locationLabel: "Gatineau, Québec, Canada" },
  "longueuil": { region: "canada", countyId: "montreal", locationLabel: "Longueuil, Québec, Canada" },
  "sherbrooke": { region: "canada", countyId: "quebec_city", locationLabel: "Sherbrooke, Québec, Canada" },
  "saguenay": { region: "canada", countyId: "quebec_city", locationLabel: "Saguenay, Québec, Canada" },
  "trois-rivieres": { region: "canada", countyId: "quebec_city", locationLabel: "Trois-Rivières, Québec, Canada" },
  "alberta": { region: "canada", countyId: "calgary", locationLabel: "Alberta, Canada" },
  "calgary": { region: "canada", countyId: "calgary", locationLabel: "Calgary, Alberta, Canada" },
  "edmonton": { region: "canada", countyId: "edmonton", locationLabel: "Edmonton, Alberta, Canada" },
  "red deer": { region: "canada", countyId: "red_deer", locationLabel: "Red Deer, Alberta, Canada" },
  "lethbridge": { region: "canada", countyId: "lethbridge", locationLabel: "Lethbridge, Alberta, Canada" },
  "medicine hat": { region: "canada", countyId: "lethbridge", locationLabel: "Medicine Hat, Alberta, Canada" },
  "fort mcmurray": { region: "canada", countyId: "edmonton", locationLabel: "Fort McMurray, Alberta, Canada" },
  "airdrie": { region: "canada", countyId: "calgary", locationLabel: "Airdrie, Alberta, Canada" },
  "grande prairie": { region: "canada", countyId: "edmonton", locationLabel: "Grande Prairie, Alberta, Canada" },
  "manitoba": { region: "canada", countyId: "winnipeg", locationLabel: "Manitoba, Canada" },
  "winnipeg": { region: "canada", countyId: "winnipeg", locationLabel: "Winnipeg, Manitoba, Canada" },
  "brandon mb": { region: "canada", countyId: "winnipeg", locationLabel: "Brandon, Manitoba, Canada" },
  "nova scotia": { region: "canada", countyId: "halifax", locationLabel: "Nova Scotia, Canada" },
  "halifax": { region: "canada", countyId: "halifax", locationLabel: "Halifax, Nova Scotia, Canada" },
  "saskatchewan": { region: "canada", countyId: "saskatoon", locationLabel: "Saskatchewan, Canada" },
  "saskatoon": { region: "canada", countyId: "saskatoon", locationLabel: "Saskatoon, Saskatchewan, Canada" },
  "regina": { region: "canada", countyId: "regina", locationLabel: "Regina, Saskatchewan, Canada" },
  "newfoundland": { region: "canada", countyId: "st_johns_nl", locationLabel: "Newfoundland, Canada" },
  "st. john's": { region: "canada", countyId: "st_johns_nl", locationLabel: "St. John's, Newfoundland, Canada" },
  "st johns": { region: "canada", countyId: "st_johns_nl", locationLabel: "St. John's, Newfoundland, Canada" },
  "new brunswick": { region: "canada", countyId: "moncton", locationLabel: "New Brunswick, Canada" },
  "moncton": { region: "canada", countyId: "moncton", locationLabel: "Moncton, New Brunswick, Canada" },
  "fredericton": { region: "canada", countyId: "moncton", locationLabel: "Fredericton, New Brunswick, Canada" },
  "saint john nb": { region: "canada", countyId: "moncton", locationLabel: "Saint John, New Brunswick, Canada" },
  "prince edward island": { region: "canada", countyId: "moncton", locationLabel: "Prince Edward Island, Canada" },
  "pei": { region: "canada", countyId: "moncton", locationLabel: "Prince Edward Island, Canada" },
  "charlottetown": { region: "canada", countyId: "moncton", locationLabel: "Charlottetown, Prince Edward Island, Canada" },
  // UAE / Dubai
  "dubai": { region: "uae", countyId: "dubai", locationLabel: "Dubai, UAE" },
  "uae": { region: "uae", countyId: "dubai", locationLabel: "Dubai, UAE" },
  "united arab emirates": { region: "uae", countyId: "dubai", locationLabel: "Dubai, UAE" },
  "abu dhabi": { region: "uae", countyId: "dubai", locationLabel: "Abu Dhabi, UAE" },
  "sharjah": { region: "uae", countyId: "dubai", locationLabel: "Sharjah, UAE" },
  "jbr": { region: "uae", countyId: "dubai", locationLabel: "Dubai, UAE" },
  "difc": { region: "uae", countyId: "dubai", locationLabel: "Dubai, UAE" },
  "downtown dubai": { region: "uae", countyId: "dubai", locationLabel: "Dubai, UAE" },
  "palm jumeirah": { region: "uae", countyId: "dubai", locationLabel: "Dubai, UAE" },
  "marina dubai": { region: "uae", countyId: "dubai", locationLabel: "Dubai, UAE" },
  "deira": { region: "uae", countyId: "dubai", locationLabel: "Dubai, UAE" },
  "bur dubai": { region: "uae", countyId: "dubai", locationLabel: "Dubai, UAE" },
  "jumeirah": { region: "uae", countyId: "dubai", locationLabel: "Dubai, UAE" },
  // UK
  "uk": { region: "uk", countyId: "uk_fsa", locationLabel: "United Kingdom" },
  "united kingdom": { region: "uk", countyId: "uk_fsa", locationLabel: "United Kingdom" },
  "great britain": { region: "uk", countyId: "uk_fsa", locationLabel: "United Kingdom" },
  "britain": { region: "uk", countyId: "uk_fsa", locationLabel: "United Kingdom" },
  "england": { region: "uk", countyId: "uk_fsa", locationLabel: "England, UK" },
  "scotland": { region: "uk", countyId: "uk_fsa", locationLabel: "Scotland, UK" },
  "wales": { region: "uk", countyId: "uk_fsa", locationLabel: "Wales, UK" },
  "northern ireland": { region: "uk", countyId: "uk_fsa", locationLabel: "Northern Ireland, UK" },
  "london": { region: "uk", countyId: "uk_fsa", locationLabel: "London, England, UK" },
  "birmingham": { region: "uk", countyId: "uk_fsa", locationLabel: "Birmingham, England, UK" },
  "manchester": { region: "uk", countyId: "uk_fsa", locationLabel: "Manchester, England, UK" },
  "leeds": { region: "uk", countyId: "uk_fsa", locationLabel: "Leeds, England, UK" },
  "liverpool": { region: "uk", countyId: "uk_fsa", locationLabel: "Liverpool, England, UK" },
  "sheffield": { region: "uk", countyId: "uk_fsa", locationLabel: "Sheffield, England, UK" },
  "bristol": { region: "uk", countyId: "uk_fsa", locationLabel: "Bristol, England, UK" },
  "newcastle": { region: "uk", countyId: "uk_fsa", locationLabel: "Newcastle, England, UK" },
  "nottingham": { region: "uk", countyId: "uk_fsa", locationLabel: "Nottingham, England, UK" },
  "leicester": { region: "uk", countyId: "uk_fsa", locationLabel: "Leicester, England, UK" },
  "coventry": { region: "uk", countyId: "uk_fsa", locationLabel: "Coventry, England, UK" },
  "bradford": { region: "uk", countyId: "uk_fsa", locationLabel: "Bradford, England, UK" },
  "southampton": { region: "uk", countyId: "uk_fsa", locationLabel: "Southampton, England, UK" },
  "portsmouth": { region: "uk", countyId: "uk_fsa", locationLabel: "Portsmouth, England, UK" },
  "oxford": { region: "uk", countyId: "uk_fsa", locationLabel: "Oxford, England, UK" },
  "cambridge": { region: "uk", countyId: "uk_fsa", locationLabel: "Cambridge, England, UK" },
  "york": { region: "uk", countyId: "uk_fsa", locationLabel: "York, England, UK" },
  "bath": { region: "uk", countyId: "uk_fsa", locationLabel: "Bath, England, UK" },
  "exeter": { region: "uk", countyId: "uk_fsa", locationLabel: "Exeter, England, UK" },
  "norwich": { region: "uk", countyId: "uk_fsa", locationLabel: "Norwich, England, UK" },
  "derby": { region: "uk", countyId: "uk_fsa", locationLabel: "Derby, England, UK" },
  "stoke": { region: "uk", countyId: "uk_fsa", locationLabel: "Stoke-on-Trent, England, UK" },
  "stoke-on-trent": { region: "uk", countyId: "uk_fsa", locationLabel: "Stoke-on-Trent, England, UK" },
  "wolverhampton": { region: "uk", countyId: "uk_fsa", locationLabel: "Wolverhampton, England, UK" },
  "hull": { region: "uk", countyId: "uk_fsa", locationLabel: "Hull, England, UK" },
  "kingston upon hull": { region: "uk", countyId: "uk_fsa", locationLabel: "Hull, England, UK" },
  "middlesbrough": { region: "uk", countyId: "uk_fsa", locationLabel: "Middlesbrough, England, UK" },
  "sunderland": { region: "uk", countyId: "uk_fsa", locationLabel: "Sunderland, England, UK" },
  "reading": { region: "uk", countyId: "uk_fsa", locationLabel: "Reading, England, UK" },
  "blackpool": { region: "uk", countyId: "uk_fsa", locationLabel: "Blackpool, England, UK" },
  "bolton": { region: "uk", countyId: "uk_fsa", locationLabel: "Bolton, England, UK" },
  "salford": { region: "uk", countyId: "uk_fsa", locationLabel: "Salford, England, UK" },
  "wigan": { region: "uk", countyId: "uk_fsa", locationLabel: "Wigan, England, UK" },
  "stockport": { region: "uk", countyId: "uk_fsa", locationLabel: "Stockport, England, UK" },
  "oldham": { region: "uk", countyId: "uk_fsa", locationLabel: "Oldham, England, UK" },
  "ipswich": { region: "uk", countyId: "uk_fsa", locationLabel: "Ipswich, England, UK" },
  "peterborough": { region: "uk", countyId: "uk_fsa", locationLabel: "Peterborough, England, UK" },
  "luton": { region: "uk", countyId: "uk_fsa", locationLabel: "Luton, England, UK" },
  "milton keynes": { region: "uk", countyId: "uk_fsa", locationLabel: "Milton Keynes, England, UK" },
  "watford": { region: "uk", countyId: "uk_fsa", locationLabel: "Watford, England, UK" },
  "gloucester": { region: "uk", countyId: "uk_fsa", locationLabel: "Gloucester, England, UK" },
  "cheltenham": { region: "uk", countyId: "uk_fsa", locationLabel: "Cheltenham, England, UK" },
  "worcester": { region: "uk", countyId: "uk_fsa", locationLabel: "Worcester, England, UK" },
  "lincoln": { region: "uk", countyId: "uk_fsa", locationLabel: "Lincoln, England, UK" },
  "chester": { region: "uk", countyId: "uk_fsa", locationLabel: "Chester, England, UK" },
  "canterbury": { region: "uk", countyId: "uk_fsa", locationLabel: "Canterbury, England, UK" },
  "winchester": { region: "uk", countyId: "uk_fsa", locationLabel: "Winchester, England, UK" },
  "salisbury": { region: "uk", countyId: "uk_fsa", locationLabel: "Salisbury, England, UK" },
  "guildford": { region: "uk", countyId: "uk_fsa", locationLabel: "Guildford, England, UK" },
  "surrey": { region: "uk", countyId: "uk_fsa", locationLabel: "Surrey, England, UK" },
  "kent england": { region: "uk", countyId: "uk_fsa", locationLabel: "Kent, England, UK" },
  "kent uk": { region: "uk", countyId: "uk_fsa", locationLabel: "Kent, England, UK" },
  "essex": { region: "uk", countyId: "uk_fsa", locationLabel: "Essex, England, UK" },
  "hertfordshire": { region: "uk", countyId: "uk_fsa", locationLabel: "Hertfordshire, England, UK" },
  "west yorkshire": { region: "uk", countyId: "uk_fsa", locationLabel: "West Yorkshire, England, UK" },
  "south yorkshire": { region: "uk", countyId: "uk_fsa", locationLabel: "South Yorkshire, England, UK" },
  "lancashire": { region: "uk", countyId: "uk_fsa", locationLabel: "Lancashire, England, UK" },
  "cornwall": { region: "uk", countyId: "uk_fsa", locationLabel: "Cornwall, England, UK" },
  "devon": { region: "uk", countyId: "uk_fsa", locationLabel: "Devon, England, UK" },
  "suffolk": { region: "uk", countyId: "uk_fsa", locationLabel: "Suffolk, England, UK" },
  "norfolk": { region: "uk", countyId: "uk_fsa", locationLabel: "Norfolk, England, UK" },
  "westminster": { region: "uk", countyId: "uk_fsa", locationLabel: "Westminster, London, UK" },
  "shoreditch": { region: "uk", countyId: "uk_fsa", locationLabel: "Shoreditch, London, UK" },
  "soho london": { region: "uk", countyId: "uk_fsa", locationLabel: "Soho, London, UK" },
  "canary wharf": { region: "uk", countyId: "uk_fsa", locationLabel: "Canary Wharf, London, UK" },
  "covent garden": { region: "uk", countyId: "uk_fsa", locationLabel: "Covent Garden, London, UK" },
  "notting hill": { region: "uk", countyId: "uk_fsa", locationLabel: "Notting Hill, London, UK" },
  "camden": { region: "uk", countyId: "uk_fsa", locationLabel: "Camden, London, UK" },
  "islington": { region: "uk", countyId: "uk_fsa", locationLabel: "Islington, London, UK" },
  "hackney": { region: "uk", countyId: "uk_fsa", locationLabel: "Hackney, London, UK" },
  "brixton": { region: "uk", countyId: "uk_fsa", locationLabel: "Brixton, London, UK" },
  "peckham": { region: "uk", countyId: "uk_fsa", locationLabel: "Peckham, London, UK" },
  "greenwich": { region: "uk", countyId: "uk_fsa", locationLabel: "Greenwich, London, UK" },
  "croydon": { region: "uk", countyId: "uk_fsa", locationLabel: "Croydon, London, UK" },
  "wimbledon": { region: "uk", countyId: "uk_fsa", locationLabel: "Wimbledon, London, UK" },
  "richmond london": { region: "uk", countyId: "uk_fsa", locationLabel: "Richmond, London, UK" },
  "chelsea london": { region: "uk", countyId: "uk_fsa", locationLabel: "Chelsea, London, UK" },
  "kensington": { region: "uk", countyId: "uk_fsa", locationLabel: "Kensington, London, UK" },
  "hammersmith": { region: "uk", countyId: "uk_fsa", locationLabel: "Hammersmith, London, UK" },
  "ealing": { region: "uk", countyId: "uk_fsa", locationLabel: "Ealing, London, UK" },
  "stratford": { region: "uk", countyId: "uk_fsa", locationLabel: "Stratford, London, UK" },
  "edinburgh": { region: "uk", countyId: "uk_fsa", locationLabel: "Edinburgh, Scotland, UK" },
  "glasgow": { region: "uk", countyId: "uk_fsa", locationLabel: "Glasgow, Scotland, UK" },
  "aberdeen": { region: "uk", countyId: "uk_fsa", locationLabel: "Aberdeen, Scotland, UK" },
  "dundee": { region: "uk", countyId: "uk_fsa", locationLabel: "Dundee, Scotland, UK" },
  "inverness": { region: "uk", countyId: "uk_fsa", locationLabel: "Inverness, Scotland, UK" },
  "stirling": { region: "uk", countyId: "uk_fsa", locationLabel: "Stirling, Scotland, UK" },
  "st andrews": { region: "uk", countyId: "uk_fsa", locationLabel: "St Andrews, Scotland, UK" },
  "highlands": { region: "uk", countyId: "uk_fsa", locationLabel: "Highlands, Scotland, UK" },
  "cardiff": { region: "uk", countyId: "uk_fsa", locationLabel: "Cardiff, Wales, UK" },
  "swansea": { region: "uk", countyId: "uk_fsa", locationLabel: "Swansea, Wales, UK" },
  "newport wales": { region: "uk", countyId: "uk_fsa", locationLabel: "Newport, Wales, UK" },
  "wrexham": { region: "uk", countyId: "uk_fsa", locationLabel: "Wrexham, Wales, UK" },
  "belfast": { region: "uk", countyId: "uk_fsa", locationLabel: "Belfast, Northern Ireland, UK" },
  "derry": { region: "uk", countyId: "uk_fsa", locationLabel: "Derry, Northern Ireland, UK" },
  "londonderry": { region: "uk", countyId: "uk_fsa", locationLabel: "Derry, Northern Ireland, UK" },
  // Montgomery County MD
  "rockville": { region: "maryland", countyId: "montgomery_md" },
  "bethesda": { region: "maryland", countyId: "montgomery_md" },
  "silver spring": { region: "maryland", countyId: "montgomery_md" },
  "gaithersburg": { region: "maryland", countyId: "montgomery_md" },
  "germantown": { region: "maryland", countyId: "montgomery_md" },
  "chevy chase": { region: "maryland", countyId: "montgomery_md" },
  "potomac": { region: "maryland", countyId: "montgomery_md" },
  "montgomery county": { region: "maryland", countyId: "montgomery_md" },
  "montgomery county md": { region: "maryland", countyId: "montgomery_md" },
  // Delaware
  "delaware": { region: "delaware", countyId: "delaware", locationLabel: "Delaware" },
  "wilmington": { region: "delaware", countyId: "delaware", locationLabel: "Wilmington, Delaware" },
  "dover": { region: "delaware", countyId: "delaware", locationLabel: "Dover, Delaware" },
  "newark de": { region: "delaware", countyId: "delaware", locationLabel: "Newark, Delaware" },
  "middletown de": { region: "delaware", countyId: "delaware", locationLabel: "Middletown, Delaware" },
  "rehoboth beach": { region: "delaware", countyId: "delaware", locationLabel: "Rehoboth Beach, Delaware" },
  "lewes": { region: "delaware", countyId: "delaware", locationLabel: "Lewes, Delaware" },
  "hockessin": { region: "delaware", countyId: "delaware", locationLabel: "Hockessin, Delaware" },
  "claymont": { region: "delaware", countyId: "delaware", locationLabel: "Claymont, Delaware" },
  // New York State (outside NYC)
  "buffalo": { region: "new_york", countyId: "ny_state", locationLabel: "Buffalo, New York" },
  "rochester ny": { region: "new_york", countyId: "ny_state", locationLabel: "Rochester, New York" },
  "rochester new york": { region: "new_york", countyId: "ny_state", locationLabel: "Rochester, New York" },
  "syracuse": { region: "new_york", countyId: "ny_state", locationLabel: "Syracuse, New York" },
  "albany": { region: "new_york", countyId: "ny_state", locationLabel: "Albany, New York" },
  "yonkers": { region: "new_york", countyId: "ny_state", locationLabel: "Yonkers, New York" },
  "new rochelle": { region: "new_york", countyId: "ny_state", locationLabel: "New Rochelle, New York" },
  "white plains": { region: "new_york", countyId: "ny_state", locationLabel: "White Plains, New York" },
  "utica": { region: "new_york", countyId: "ny_state", locationLabel: "Utica, New York" },
  "schenectady": { region: "new_york", countyId: "ny_state", locationLabel: "Schenectady, New York" },
  "binghamton": { region: "new_york", countyId: "ny_state", locationLabel: "Binghamton, New York" },
  "long island": { region: "new_york", countyId: "ny_state", locationLabel: "Long Island, New York" },
  "nassau county": { region: "new_york", countyId: "ny_state", locationLabel: "Nassau County, New York" },
  "westchester county": { region: "new_york", countyId: "ny_state", locationLabel: "Westchester County, New York" },
  "ithaca": { region: "new_york", countyId: "ny_state", locationLabel: "Ithaca, New York" },
  "saratoga springs": { region: "new_york", countyId: "ny_state", locationLabel: "Saratoga Springs, New York" },
  "poughkeepsie": { region: "new_york", countyId: "ny_state", locationLabel: "Poughkeepsie, New York" },
  "endwell": { region: "new_york", countyId: "ny_state", locationLabel: "Endwell, New York" },
};

const LIVE_API_CITIES = [
  { label: "Seattle / King Co.", region: "washington", countyId: "king", emoji: "🌲", example: "McDonald's" },
  { label: "New York City", region: "new_york", countyId: "nyc", emoji: "🗽", example: "Subway" },
  { label: "NY State (Buffalo, Albany…)", region: "new_york", countyId: "ny_state", emoji: "🏔️", example: "pizza", locationLabel: "New York State" },
  { label: "Chicago", region: "illinois", countyId: "cook", emoji: "🏙️", example: "pizza" },
  { label: "Montgomery Co. MD", region: "maryland", countyId: "montgomery_md", emoji: "🏛️", example: "Chipotle" },
  { label: "Austin TX", region: "texas", countyId: "travis", emoji: "🤠", example: "tacos" },
  { label: "San Francisco", region: "california", countyId: "sf", emoji: "🌉", example: "sushi" },
  { label: "Los Angeles", region: "california", countyId: "la", emoji: "🌴", example: "burger" },
  { label: "Toronto 🇨🇦", region: "canada", countyId: "toronto", emoji: "🍁", example: "restaurant", locationLabel: "Toronto, Ontario, Canada" },
  { label: "Delaware", region: "delaware", countyId: "delaware", emoji: "🦅", example: "Subway", locationLabel: "Delaware" },
  { label: "Dubai 🇦🇪", region: "uae", countyId: "dubai", emoji: "🏙️", example: "restaurant", locationLabel: "Dubai, UAE" },
  { label: "United Kingdom 🇬🇧", region: "uk", countyId: "uk_fsa", emoji: "🇬🇧", example: "fish and chips", locationLabel: "United Kingdom" },
];

export default function Home() {
  const location = useLocation();
  const { accept, decline } = useConsent();
  const [region, setRegion]                     = useState("global");
  const [countyId, setCountyId]                 = useState("global");
  const pendingSearchRef                        = useRef(null);
  const [results, setResults]                   = useState([]);
  const [selectedBusiness, setSelectedBusiness] = useState(null);
  const [detailRows, setDetailRows]             = useState([]);
  const [isLoading, setIsLoading]               = useState(false);
  const abortRef                                = useRef(null);
  const [isDetailLoading, setIsDetailLoading]   = useState(false);
  const [hasSearched, setHasSearched]           = useState(false);
  const [searchQuery, setSearchQuery]           = useState("");
  const [searchBarQuery, setSearchBarQuery]     = useState("");
  const [viewMode, setViewMode]                 = useState("list");
  const [sortBy, setSortBy]                     = useState("score-high");
  const [gradeFilter, setGradeFilter]           = useState(null);
  const [compareList, setCompareList]           = useState([]);
  const [showCompare, setShowCompare]           = useState(false);
  const [nearMeActive, setNearMeActive]         = useState(false);
  const [userCoords, setUserCoords]             = useState(null);
  const [isGeolocating, setIsGeolocating]       = useState(false);
  const [nearMeError, setNearMeError]           = useState("");
  const [showScanner, setShowScanner]           = useState(false);
  const [locationQuery, setLocationQuery]       = useState("");
  const [isAISearch, setIsAISearch]             = useState(false);
  const [searchError, setSearchError]           = useState("");
  const [fastResults, setFastResults]           = useState(null);

  const handleToggleCompare = (restaurant) => {
    setCompareList((prev) => {
      const exists = prev.find((r) => r.business_id === restaurant.business_id);
      if (exists) return prev.filter((r) => r.business_id !== restaurant.business_id);
      if (prev.length >= 3) return prev;
      return [...prev, restaurant];
    });
  };

  const currentRegion = REGIONS[region] || REGIONS["global"];
  const currentCounty = currentRegion.counties.find((c) => c.id === countyId) || currentRegion.counties[0];
  const { t: langT } = useLanguage();
  const t = langT || getTranslations(region);
  const { langMeta } = useLanguage();
  const isRTL = langMeta?.dir === "rtl" || ["uae"].includes(region);

  // Silently grab user coords if already permitted (no prompt)
  useEffect(() => {
    if (!navigator.geolocation) return;
    navigator.permissions?.query({ name: 'geolocation' }).then((result) => {
      if (result.state === 'granted') {
        navigator.geolocation.getCurrentPosition((pos) => {
          setUserCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        }, () => {});
      }
    }).catch(() => {});
  }, []);

  // Auto-search from URL params (e.g. navigated here from CountyDrillDown)
  useEffect(() => {
    if (location.state?.restaurant) {
      const { restaurant, region: r, county: c } = location.state;
      if (r && REGIONS[r]) setRegion(r);
      if (c) setCountyId(c);
      setHasSearched(true);
      setSelectedBusiness(restaurant);
      setDetailRows(llmToDetailRows(restaurant));
      return;
    }
    const params = new URLSearchParams(window.location.search);
    const q = params.get("q");
    const r = params.get("region");
    const c = params.get("county");
    if (q) {
      if (r && REGIONS[r]) setRegion(r);
      if (c) setCountyId(c);
      pendingSearchRef.current = q;
    }
  }, []);

  useEffect(() => {
    if (pendingSearchRef.current) {
      const q = pendingSearchRef.current;
      pendingSearchRef.current = null;
      handleSearch(q);
    }
  }, [countyId]);

  const resetSearch = () => {
    setResults([]);
    setHasSearched(false);
    setSelectedBusiness(null);
    setFastResults(null);
    window.history.pushState({}, '', window.location.pathname);
    setViewMode("list");
    setCompareList([]);
    setShowCompare(false);
    setGradeFilter(null);
  };

  const handleSearch = useCallback(async (rawQuery) => {
    let query = rawQuery;
    let searchRegion = region;
    let searchCounty = countyId;

    // Auto-detect location from explicit city name in query when on global
    if (searchRegion === "global" || searchCounty === "global") {
      const queryWords = rawQuery.toLowerCase().trim();
      const sortedKeys = Object.keys(CITY_TO_COUNTY).sort((a, b) => b.length - a.length);
      for (const key of sortedKeys) {
        if (queryWords.includes(key)) {
          const matched = CITY_TO_COUNTY[key];
          if (REGIONS[matched.region]) {
            searchRegion = matched.region;
            searchCounty = matched.countyId;
            setRegion(searchRegion);
            setCountyId(searchCounty);
            if (matched.locationLabel) setLocationQuery(matched.locationLabel);
            query = rawQuery.replace(new RegExp(key, "i"), "").trim().replace(/^,\s*/, "") || rawQuery;
          }
          break;
        }
      }
    }

    if (abortRef.current) abortRef.current.abort();
    const controller = new AbortController();
    abortRef.current = controller;
    const signal = controller.signal;

    setIsLoading(true);
    setFastResults(null);
    setHasSearched(true);
    setSearchQuery(rawQuery);
    setSelectedBusiness(null);
    setViewMode("list");
    setSearchError("");

    const resolvedCounty = (REGIONS[searchRegion]?.counties || []).find((c) => c.id === searchCounty) || { name: searchCounty };
    const locationCtx = locationQuery.trim() || resolvedCounty.name;

    if (searchCounty !== "king" && !["nyc","cook","montgomery_md","travis","sf","la","uk_fsa","toronto","delaware","ny_state"].includes(searchCounty)) {
      setIsAISearch(true);
    }

    try {
      const today = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });

      const { results: fetchedResults, isAI } = await engineSearch({
        query,
        countyId: searchCounty,
        locationLabel: locationCtx,
        today,
        signal,
        onFastResults: (fast) => setFastResults(fast),
        onCountUpdate: (bizId, trueCount) => {
          setResults(prev => prev.map(r =>
            r.business_id === bizId ? { ...r, totalInspections: trueCount } : r
          ));
        },
      });

      setIsAISearch(isAI);
      setResults(fetchedResults);
    } catch (e) {
      if (e.name === "AbortError") return;
      setIsLoading(false);
      setIsAISearch(false);
      setSearchError("Search failed. Please try again in a moment.");
      return;
    }

    setIsLoading(false);
    setIsAISearch(false);
  }, [region, countyId, locationQuery, userCoords]);

  const handleSelectBusiness = useCallback(async (biz) => {
    setSelectedBusiness(biz);
    window.history.pushState({}, '', `?q=${encodeURIComponent(searchQuery)}&biz=${encodeURIComponent(biz.business_id)}`);

    setIsDetailLoading(true);

    const processRows = (rows) => {
      setDetailRows(rows);
      if (rows.length === 0) return;

      const uniqueMap = {};
      rows.forEach(row => {
        const key = row.inspection_serial_num || `${row.inspection_date}|${row.inspection_result}`;
        if (!uniqueMap[key]) uniqueMap[key] = row;
      });
      const uniqueRows = Object.values(uniqueMap);

      const actualCount = uniqueRows.length;
      const sortedDates = uniqueRows.map(r => r.inspection_date).filter(Boolean).sort((a, b) => new Date(b) - new Date(a));
      const trueLatestDate = sortedDates[0] || biz.latestDate;
      const mostRecent = uniqueRows.find(r => r.inspection_date === trueLatestDate) || uniqueRows[0];
      const trueLatestResult = mostRecent?.inspection_result || biz.latestResult;

      let trueSafetyScore = biz.safetyScore;
      const scoresFromRows = uniqueRows
        .map(r => {
          const raw = r.inspection_score !== undefined ? r.inspection_score : r.score;
          return raw !== undefined ? Math.max(0, Math.min(100, 100 - parseInt(raw))) : null;
        })
        .filter(s => s !== null && !isNaN(s));
      if (scoresFromRows.length > 0) {
        const latestScoreRaw = mostRecent?.inspection_score !== undefined ? mostRecent.inspection_score : mostRecent?.score;
        if (latestScoreRaw !== undefined && latestScoreRaw !== null) {
          trueSafetyScore = Math.max(0, Math.min(100, 100 - parseInt(latestScoreRaw)));
        }
      }

      const enriched = {
        ...biz,
        totalInspections: actualCount,
        latestDate: trueLatestDate,
        latestResult: trueLatestResult,
        safetyScore: trueSafetyScore,
        inspectionHistory: uniqueRows,
      };
      setSelectedBusiness(enriched);
      setResults(prev => prev.map(r =>
        r.business_id === biz.business_id
          ? { ...r, totalInspections: actualCount, latestDate: trueLatestDate, latestResult: trueLatestResult, safetyScore: trueSafetyScore }
          : r
      ));
    };

    const rows = await engineFetchDetail(biz);
    processRows(rows);
    setIsDetailLoading(false);
  }, [searchQuery]);

  const handleSwitchToMap = useCallback(() => setViewMode("map"), []);

  // Haversine distance in miles
  const haversineMiles = (lat1, lon1, lat2, lon2) => {
    const R = 3958.8;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat/2)**2 + Math.cos(lat1*Math.PI/180) * Math.cos(lat2*Math.PI/180) * Math.sin(dLon/2)**2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  };

  const handleFindNearMe = useCallback(async () => {
    if (nearMeActive) { setNearMeActive(false); setUserCoords(null); setNearMeError(""); return; }
    setNearMeError("");
    setIsGeolocating(true);
    const geoContext = locationQuery.trim() || REGIONS[region]?.abbr || "";
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const coords = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        setUserCoords(coords);
        const missing = results.filter((r) => !r.latitude || !r.longitude);
        await Promise.all(missing.map(async (r) => {
          const gc = await geocodeAddress(r.address, r.city, geoContext).catch(() => null);
          if (gc) setResults((prev) => prev.map((p) => p.business_id === r.business_id ? { ...p, ...gc } : p));
        }));
        setNearMeActive(true);
        setIsGeolocating(false);
      },
      () => { setNearMeError("Location access denied."); setIsGeolocating(false); }
    );
  }, [nearMeActive, region, locationQuery, results]);

  const filteredAndSortedResults = useMemo(() => {
    let filtered = [...results];
    if (gradeFilter) {
      const gradeRanges = { A: [90, 100], B: [80, 89], C: [70, 79], D: [60, 69], F: [0, 59] };
      if (gradeFilter === "U") {
        filtered = filtered.filter((r) => r.safetyScore === null || r.safetyScore === undefined || r.totalInspections === 0);
      } else {
        const [lo, hi] = gradeRanges[gradeFilter] || [0, 100];
        filtered = filtered.filter((r) => r.safetyScore !== null && r.safetyScore !== undefined && r.safetyScore >= lo && r.safetyScore <= hi);
      }
    }
    const scoreOf = (r) => r.safetyScore !== null && r.safetyScore !== undefined ? r.safetyScore : -1;
    switch (sortBy) {
      case "score-high":  filtered.sort((a, b) => scoreOf(b) - scoreOf(a) || b.totalInspections - a.totalInspections); break;
      case "score-low":   filtered.sort((a, b) => scoreOf(a) - scoreOf(b) || b.totalInspections - a.totalInspections); break;
      case "inspections": filtered.sort((a, b) => b.totalInspections - a.totalInspections || scoreOf(b) - scoreOf(a)); break;
      case "date-recent": filtered.sort((a, b) => new Date(b.latestDate) - new Date(a.latestDate)); break;
      case "date-oldest": filtered.sort((a, b) => new Date(a.latestDate) - new Date(b.latestDate)); break;
      default:            filtered.sort((a, b) => scoreOf(b) - scoreOf(a));
    }
    if (nearMeActive && userCoords) {
      filtered = filtered.filter((r) => {
        if (!r.latitude || !r.longitude) return false;
        return haversineMiles(userCoords.lat, userCoords.lng, parseFloat(r.latitude), parseFloat(r.longitude)) <= 5;
      });
    }
    return filtered;
  }, [results, sortBy, nearMeActive, userCoords, gradeFilter]);

  const handleGeocodedMapSwitch = useCallback((sortedResults) => {
    const MAP_LIMIT = 10;
    const topResults = sortedResults.slice(0, MAP_LIMIT);
    if (!topResults.some((r) => !r.latitude)) return;
    const geoContext = locationQuery.trim() || REGIONS[region]?.abbr || "";
    topResults.forEach(async (r) => {
      if (r.latitude && r.longitude) return;
      const coords = await geocodeAddress(r.address, r.city, geoContext).catch(() => null);
      if (coords) {
        setResults((prev) => prev.map((p) => p.business_id === r.business_id ? { ...p, ...coords } : p));
      }
    });
  }, [region, locationQuery]);

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Hero */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-[#1a2e1a] text-white" role="banner">
        <div className="max-w-5xl mx-auto px-4 pt-10 pb-8 sm:pt-14 sm:pb-10">
          <div className="text-center mb-7">
            <div className="inline-flex items-center gap-2 bg-[#4CAF50]/20 border border-[#4CAF50]/40 text-[#81c784] text-xs font-bold px-3 py-1.5 rounded-full mb-4 tracking-wider uppercase">
              🛡️ #1 Global Food Safety Platform · 195+ Countries
            </div>
            <h1 className="text-4xl sm:text-5xl font-black tracking-tight leading-tight" dir={isRTL ? "rtl" : "ltr"} style={{ fontFamily: "Nunito, sans-serif" }}>
              Is your restaurant
              <span className="text-[#4CAF50]"> safe to eat at? 🍽️</span>
            </h1>
            <p className="mt-3 text-base sm:text-lg text-slate-300 font-bold max-w-lg mx-auto" style={{ fontFamily: "Nunito, sans-serif" }}>
              Real health inspector reports — made easy to understand! Find out if your favorite restaurant is A+ or needs a time-out. 🛡️
            </p>

            {!hasSearched && (
              <div className="flex items-center justify-center gap-2 mt-5 flex-wrap" style={{ fontFamily: "Nunito, sans-serif" }}>
                {[
                  { g: "A", color: "bg-green-600 text-white", tip: "🌟 Amazing!" },
                  { g: "B", color: "bg-lime-500 text-white", tip: "😊 Great!" },
                  { g: "C", color: "bg-yellow-400 text-slate-800", tip: "🤔 Okay" },
                  { g: "D", color: "bg-orange-500 text-white", tip: "⚠️ Uh-oh" },
                  { g: "F", color: "bg-red-600 text-white", tip: "🚨 Yikes!" },
                  { g: "U", color: "bg-slate-400 text-white", tip: "❓ Unknown" },
                ].map(({ g, color, tip }) => (
                  <div key={g} className="flex flex-col items-center gap-1">
                    <span className={`w-11 h-11 rounded-2xl flex items-center justify-center font-black text-xl shadow-md border-2 border-white/30 ${color}`}>{g}</span>
                    <span className="text-[10px] text-slate-300 font-extrabold">{tip}</span>
                  </div>
                ))}
                <Link to="/About#grading" className="text-slate-400 text-xs ml-1 hover:text-[#4CAF50] underline underline-offset-2 transition-colors font-bold">← how grades work</Link>
              </div>
            )}
          </div>

          <SmartSearchPanel
            query={searchBarQuery}
            onQueryChange={setSearchBarQuery}
            locationQuery={locationQuery}
            onLocationChange={(val) => {
              setLocationQuery(val);
              const key = val.toLowerCase().trim();
              const match = CITY_TO_COUNTY[key];
              if (match && REGIONS[match.region]) {
                setRegion(match.region);
                setCountyId(match.countyId);
                if (match.locationLabel) setLocationQuery(match.locationLabel);
              } else {
                setRegion("global");
                setCountyId("global");
              }
            }}
            onRegionChange={({ region: r, countyId: c, label }) => {
              setRegion(r);
              setCountyId(c);
              setLocationQuery(label);
            }}
            onSearch={(q) => {
              if (hasSearched) resetSearch();
              setTimeout(() => handleSearch(q), 0);
            }}
            isLoading={isLoading}
            activeRegion={region}
            activeCounty={countyId}
            onNearMe={(coords) => {
              setUserCoords(coords);
              setNearMeActive(true);
            }}
          />

          <div className="flex justify-center gap-2 mt-4">
            {hasSearched && (
              <button onClick={resetSearch} className="flex items-center gap-1.5 px-4 py-2.5 rounded-2xl bg-red-600 hover:bg-red-500 text-white text-sm font-bold min-h-[48px] transition-colors">
                <X className="w-4 h-4" /> New Search
              </button>
            )}
            <button onClick={() => setShowScanner(true)} className="flex items-center gap-1.5 px-4 py-2.5 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/15 text-white text-sm font-bold min-h-[48px] transition-colors">
              📷 {hasSearched ? "Scan Sign" : "Scan a Restaurant Sign"}
            </button>
          </div>

          {!hasSearched && (
            <div className="w-full max-w-4xl mx-auto mt-4">
              <HeroViolations />
            </div>
          )}
        </div>
      </div>

      <div aria-live="polite" aria-atomic="true" className="sr-only" id="search-status">
        {isLoading ? "Searching for restaurants, please wait…" : hasSearched && !isLoading ? `Found ${filteredAndSortedResults.length} restaurants` : ""}
      </div>

      <main className="max-w-5xl mx-auto px-4 pb-20 pt-8" id="main-content" aria-label="Restaurant search results">
        {!hasSearched && (
          <div className="space-y-8 mb-10">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4" style={{ fontFamily: "Nunito, sans-serif" }}>
              {[
                { emoji: "🔍", title: "Search any restaurant!", desc: "Type a name, like \"McDonald's\" or just \"pizza\". It works anywhere in the world!" },
                { emoji: "📋", title: "See the real grade", desc: "We grab actual health inspector reports — the same ones the inspectors write down." },
                { emoji: "🛡️", title: "Eat with confidence!", desc: "Get A–F grades in plain English, plus the full list of what inspectors found." },
              ].map(({ emoji, title, desc }) => (
                <div key={title} className="bg-white rounded-3xl border-2 border-slate-200 p-5 shadow-sm flex gap-4 items-start hover:border-[#4CAF50] hover:shadow-md transition-all">
                  <span className="text-4xl flex-shrink-0">{emoji}</span>
                  <div>
                    <h3 className="font-black text-slate-900 text-sm mb-1">{title}</h3>
                    <p className="text-xs text-slate-500 leading-relaxed font-semibold">{desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { value: "195+", label: "Countries covered", emoji: "🌍" },
                { value: "1M+", label: "Establishments tracked", emoji: "🍽️" },
                { value: "100%", label: "Free, always", emoji: "✅" },
                { value: "♿", label: "ADA accessibility checked", emoji: "" },
              ].map(({ value, label, emoji }) => (
                <div key={label} className="bg-white rounded-2xl border border-slate-200 p-4 text-center shadow-sm">
                  <p className="text-2xl font-extrabold text-slate-900">{emoji} {value}</p>
                  <p className="text-xs text-slate-500 mt-0.5 font-medium">{label}</p>
                </div>
              ))}
            </div>

            <div className="bg-slate-900 rounded-2xl p-5">
              <p className="text-xs font-bold text-slate-400 uppercase tracking-widest text-center mb-3">🟢 Cities with live government data (instant results)</p>
              <div className="flex flex-wrap justify-center gap-2">
                {["🌲 King County, WA", "🗽 New York City, NY", "🏔️ NY State (Buffalo, Albany…)", "🏙️ Chicago, IL", "🏛️ Montgomery Co., MD", "🤠 Austin, TX", "🌉 San Francisco, CA", "🌴 Los Angeles, CA", "🍁 Toronto, Canada (DineSafe)", "🦅 Delaware", "🇦🇪 Dubai, UAE", "🇬🇧 United Kingdom (500K+ establishments)"].map(src => (
                  <span key={src} className="bg-slate-800 text-slate-300 text-xs font-semibold px-3 py-1.5 rounded-full border border-slate-700">{src}</span>
                ))}
              </div>
              <p className="text-center text-xs text-slate-500 mt-3">🌍 Everywhere else is covered by AI-powered search of public health records. Just type any city or country!</p>
            </div>
          </div>
        )}

        <AnimatePresence mode="wait">
          {selectedBusiness ? (
            <motion.div key="detail" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} transition={{ duration: 0.3 }}>
              {isDetailLoading ? (
                <div className="flex flex-col items-center justify-center py-20">
                  <div className="w-10 h-10 border-2 border-slate-600 border-t-transparent rounded-full animate-spin mb-4" />
                  <p className="text-sm text-slate-400">{t.loadingDetails}</p>
                </div>
              ) : (
                <RestaurantDetail restaurant={selectedBusiness} inspections={detailRows} onBack={() => setSelectedBusiness(null)} />
              )}
            </motion.div>
          ) : (
            <motion.div key="list" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              {hasSearched && (
                <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                  <div className="lg:col-span-3">
                    {isLoading ? (
                      isAISearch ? (
                        <AISearchStatus
                          hasFastResults={fastResults !== null && fastResults.length > 0}
                          onAcceptFast={() => {
                            if (abortRef.current) abortRef.current.abort();
                            setResults(fastResults);
                            setFastResults(null);
                            setIsLoading(false);
                          }}
                          onCancel={() => {
                            if (abortRef.current) abortRef.current.abort();
                            setIsLoading(false);
                            setFastResults(null);
                          }}
                        />
                      ) : (
                        <div className="flex flex-col items-center justify-center py-20">
                          <div className="w-10 h-10 border-2 border-slate-600 border-t-transparent rounded-full animate-spin mb-4" />
                          <p className="text-sm text-slate-400">Searching live government database…</p>
                        </div>
                      )
                    ) : searchError ? (
                      <div className="flex flex-col items-center justify-center py-16">
                        <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-4">
                          <span className="text-3xl">⚠️</span>
                        </div>
                        <h3 className="text-lg font-semibold text-slate-700">Search Unavailable</h3>
                        <p className="text-sm text-slate-400 mt-1 mb-4">{searchError}</p>
                        <button onClick={() => handleSearch(searchQuery)} className="px-4 py-2 bg-slate-900 text-white rounded-xl text-sm font-semibold hover:bg-slate-700 transition-colors">Try Again</button>
                      </div>
                    ) : results.length > 0 ? (
                      <div>
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 bg-white border border-slate-200 rounded-2xl px-4 py-3 shadow-sm">
                          <div>
                            <p className="text-sm font-extrabold text-slate-800">
                              Found {filteredAndSortedResults.length} restaurant{filteredAndSortedResults.length !== 1 ? "s" : ""}
                              {results.length !== filteredAndSortedResults.length ? ` (filtered from ${results.length})` : ""}
                              {searchQuery ? ` for "${searchQuery}"` : ""}
                              {nearMeActive && <span className="ml-1 text-blue-600"> · within 5 miles</span>}
                            </p>
                            {nearMeError && <p className="text-xs text-red-500 mt-0.5">{nearMeError}</p>}
                            <p className="text-xs text-slate-400 mt-0.5">
                              {gradeFilter ? `Showing Grade ${gradeFilter} only · ` : ""}
                              Sorted by safety score — tap any restaurant to see its full history
                            </p>
                          </div>
                          <div className="flex gap-2 flex-wrap justify-end">
                            <button
                              onClick={handleFindNearMe}
                              disabled={isGeolocating}
                              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-bold transition-all border ${
                                nearMeActive ? "bg-blue-600 text-white border-blue-600" : "bg-white text-slate-700 border-slate-300 hover:bg-slate-50"
                              }`}
                            >
                              {isGeolocating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <LocateFixed className="w-3.5 h-3.5" />}
                              {nearMeActive ? "📍 Near Me ON" : "📍 Near Me"}
                            </button>
                            <button onClick={() => setViewMode("list")} className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-bold transition-all border ${viewMode === "list" ? "bg-slate-900 text-white border-slate-900" : "bg-white text-slate-700 border-slate-300 hover:bg-slate-50"}`}>
                              📋 List
                            </button>
                            <button onClick={viewMode !== "map" ? () => { handleSwitchToMap(); handleGeocodedMapSwitch(filteredAndSortedResults); } : undefined} className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-bold transition-all border ${viewMode === "map" ? "bg-slate-900 text-white border-slate-900" : "bg-white text-slate-700 border-slate-300 hover:bg-slate-50"}`}>
                              🗺️ Map
                            </button>
                          </div>
                        </div>

                        {viewMode === "map" ? (
                          <Suspense fallback={<div className="h-64 flex items-center justify-center"><div className="w-8 h-8 border-2 border-slate-400 border-t-transparent rounded-full animate-spin" /></div>}>
                            <MapView
                              restaurants={filteredAndSortedResults}
                              onSelectRestaurant={handleSelectBusiness}
                              onFilterByGrade={(grade) => setGradeFilter(grade)}
                              userCoords={userCoords}
                              selectedId={selectedBusiness?.business_id}
                            />
                          </Suspense>
                        ) : (
                          <div className="space-y-3">
                            {filteredAndSortedResults.map((r) => (
                              <RestaurantCard
                                key={r.business_id}
                                restaurant={r}
                                onClick={() => handleSelectBusiness(r)}
                                onToggleCompare={handleToggleCompare}
                                isCompared={compareList.some((c) => c.business_id === r.business_id)}
                                compareDisabled={compareList.length >= 3}
                              />
                            ))}
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="text-center py-14 bg-white rounded-2xl border border-slate-200 shadow-sm">
                        <span className="text-5xl">🤷</span>
                        <h3 className="text-lg font-extrabold text-slate-800 mt-4">Nothing found for "{searchQuery}"</h3>
                        <p className="text-sm text-slate-500 mt-2 max-w-xs mx-auto">
                          Try a different spelling, a broader word (like "pizza" or "chicken"), or make sure your location is right.
                        </p>
                        {locationQuery && (
                          <p className="text-xs text-slate-400 mt-2">
                            📍 You searched in: <span className="font-bold text-slate-600">{locationQuery}</span>
                          </p>
                        )}
                        <div className="mt-6">
                          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">Try one of these cities with live data:</p>
                          <div className="flex flex-wrap justify-center gap-2">
                            {LIVE_API_CITIES.map(city => (
                              <button key={city.countyId}
                                onClick={() => { setRegion(city.region); setCountyId(city.countyId); setLocationQuery(city.locationLabel || city.label); resetSearch(); }}
                                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900 text-white text-sm font-semibold hover:bg-slate-700 transition-colors">
                                {city.emoji} {city.label}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                  <div className="lg:col-span-1">
                    <div className="sticky top-6 space-y-3">
                      <Suspense fallback={null}>
                        <ScoreLegend
                          activeGrade={gradeFilter}
                          onGradeFilter={(g) => setGradeFilter(g)}
                        />
                      </Suspense>
                      {gradeFilter && (
                        <div className="bg-slate-100 rounded-xl px-3 py-2 text-xs text-slate-600 font-semibold flex items-center justify-between">
                          <span>Showing Grade {gradeFilter} only</span>
                          <button onClick={() => setGradeFilter(null)} className="text-blue-600 hover:underline ml-2">Clear</button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {compareList.length >= 2 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 bg-slate-900 text-white rounded-2xl shadow-2xl px-5 py-3 flex items-center gap-4 max-w-lg w-[90vw]">
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5 text-sm font-bold">
              <GitCompareArrows className="w-4 h-4 text-blue-400" />
              Compare Side-by-Side
            </div>
            <div className="flex items-center gap-1 mt-1">
              {compareList.map((r) => (
                <span key={r.business_id} className="text-[11px] bg-slate-700 px-2 py-0.5 rounded-lg truncate max-w-[100px]">{r.name}</span>
              ))}
            </div>
          </div>
          <button
            onClick={() => setShowCompare(true)}
            className="ml-auto bg-blue-500 hover:bg-blue-400 text-white text-sm font-bold px-4 py-2 rounded-xl transition-colors whitespace-nowrap"
          >
            ⚖️ Compare Now
          </button>
          <button onClick={() => setCompareList([])} title="Clear comparison" className="text-slate-400 hover:text-white transition-colors flex-shrink-0">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {showScanner && (
        <Suspense fallback={null}>
          <CameraScanner
            onResult={(query) => { handleSearch(query); }}
            onClose={() => setShowScanner(false)}
          />
        </Suspense>
      )}

      <ConsentBanner onAccept={accept} onDecline={decline} />

      {showCompare && (
        <Suspense fallback={null}>
          <ComparePanel
            restaurants={compareList}
            onClose={() => setShowCompare(false)}
            onViewDetail={(r) => { setShowCompare(false); handleSelectBusiness(r); }}
          />
        </Suspense>
      )}
    </div>
  );
}